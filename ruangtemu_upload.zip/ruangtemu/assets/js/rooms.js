(function () {
  // ---------- ROOM MODAL ----------
  const roomModal = document.getElementById('roomModal');
  const roomForm = document.getElementById('roomForm');
  const roomModalTitle = document.getElementById('roomModalTitle');
  const roomName = document.getElementById('roomName');
  const roomLocation = document.getElementById('roomLocation');
  const roomCapacity = document.getElementById('roomCapacity');
  const ADD_ROOM_URL = roomForm.action;

  function openAddRoom() {
    roomModalTitle.textContent = 'Tambah Ruangan';
    roomForm.action = ADD_ROOM_URL;
    roomName.value = '';
    roomLocation.value = '';
    roomCapacity.value = '';
    roomModal.classList.add('open');
  }
  function openEditRoom(btn) {
    roomModalTitle.textContent = 'Edit Ruangan';
    roomForm.action = ADD_ROOM_URL.replace('add_room', 'update_room/' + btn.dataset.id);
    roomName.value = btn.dataset.name;
    roomLocation.value = btn.dataset.location;
    roomCapacity.value = btn.dataset.capacity;
    roomModal.classList.add('open');
  }
  function closeRoomModal() { roomModal.classList.remove('open'); }

  document.getElementById('btnAddRoom').addEventListener('click', openAddRoom);
  document.getElementById('roomModalClose').addEventListener('click', closeRoomModal);
  document.getElementById('roomModalCancel').addEventListener('click', closeRoomModal);
  roomModal.addEventListener('click', e => { if (e.target === roomModal) closeRoomModal(); });
  document.querySelectorAll('[data-edit-room]').forEach(btn => btn.addEventListener('click', () => openEditRoom(btn)));

  // ---------- SLOT MODAL ----------
  const slotModal = document.getElementById('slotModal');
  const slotForm = document.getElementById('slotForm');
  const slotModalTitle = document.getElementById('slotModalTitle');
  const slotStart = document.getElementById('slotStart');
  const slotEnd = document.getElementById('slotEnd');
  const ADD_SLOT_URL = slotForm.action;

  function openAddSlot() {
    slotModalTitle.textContent = 'Tambah Jam';
    slotForm.action = ADD_SLOT_URL;
    slotStart.value = '8';
    slotEnd.value = '10';
    slotModal.classList.add('open');
  }
  function openEditSlot(btn) {
    slotModalTitle.textContent = 'Edit Jam';
    slotForm.action = ADD_SLOT_URL.replace('add_slot', 'update_slot/' + btn.dataset.id);
    slotStart.value = btn.dataset.start;
    slotEnd.value = btn.dataset.end;
    slotModal.classList.add('open');
  }
  function closeSlotModal() { slotModal.classList.remove('open'); }

  document.getElementById('btnAddSlot').addEventListener('click', openAddSlot);
  document.getElementById('slotModalClose').addEventListener('click', closeSlotModal);
  document.getElementById('slotModalCancel').addEventListener('click', closeSlotModal);
  slotModal.addEventListener('click', e => { if (e.target === slotModal) closeSlotModal(); });
  document.querySelectorAll('[data-edit-slot]').forEach(btn => btn.addEventListener('click', () => openEditSlot(btn)));

  document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeRoomModal(); closeSlotModal(); } });
})();
