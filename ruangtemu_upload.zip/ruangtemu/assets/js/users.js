(function () {
  const overlay = document.getElementById('modalOverlay');
  const openBtn = document.getElementById('btnAddUser');
  const closeBtn = document.getElementById('modalClose');
  const cancelBtn = document.getElementById('btnCancel');

  openBtn.addEventListener('click', () => overlay.classList.add('open'));
  closeBtn.addEventListener('click', () => overlay.classList.remove('open'));
  cancelBtn.addEventListener('click', () => overlay.classList.remove('open'));
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.classList.remove('open'); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') overlay.classList.remove('open'); });
})();
