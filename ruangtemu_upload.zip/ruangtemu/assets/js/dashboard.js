(function () {
	const CFG = window.RUANGTEMU;
	const BASE = CFG.baseUrl.replace(/\/$/, "");

	let currentDate = CFG.date;
	let bookings = CFG.bookings || {}; // keyed "roomId|slotLabel"
	let modalBookings = {};

	const STATUS_CLASS = {
		Disetujui: "approved",
		Menunggu: "pending",
		Ditolak: "rejected",
	};

	function toLocalISO(date) {
		const y = date.getFullYear();
		const m = String(date.getMonth() + 1).padStart(2, "0");
		const d = String(date.getDate()).padStart(2, "0");
		return `${y}-${m}-${d}`;
	}
	function todayISO() {
		return toLocalISO(new Date());
	}
	const currentHour = new Date().getHours();
	const isPastDate = (date) => date < todayISO();
	const isPastSlot = (date, slot) =>
		isPastDate(date) || (date === todayISO() && slot.end_hour <= currentHour);

	function fmtDateID(iso) {
		const d = new Date(iso + "T00:00:00");
		return d.toLocaleDateString("id-ID", {
			weekday: "long",
			day: "2-digit",
			month: "long",
			year: "numeric",
		});
	}

	function cellEl(cls, text) {
		const d = document.createElement("div");
		d.className = cls;
		d.textContent = text;
		return d;
	}

	function renderTimeline() {
		const el = document.getElementById("timeline");
		el.innerHTML = "";
		el.appendChild(cellEl("tl-corner", "Ruangan"));
		CFG.slots.forEach((s) => el.appendChild(cellEl("tl-head", s.label)));

		let available = 0,
			approved = 0,
			pending = 0;

		CFG.rooms.forEach((room) => {
			const roomCell = document.createElement("div");
			roomCell.className = "tl-room";
			roomCell.innerHTML = `
        <span class="tl-room-name">${room.name}</span>
        <span class="tl-room-loc">Ruang Meeting ${room.location}</span>
        <span class="tl-room-cap">👤 hingga ${room.capacity} orang</span>`;
			el.appendChild(roomCell);

			CFG.slots.forEach((slot) => {
				const bkRaw = bookings[room.id + "|" + slot.label];
				// A rejected request no longer occupies the slot — treat it as if
				// nothing was ever booked here, so anyone can freely re-apply.
				const bk = bkRaw && bkRaw.status === "Ditolak" ? null : bkRaw;
				const past = isPastSlot(currentDate, slot);
				const c = document.createElement("div");

				if (past && !bk) {
					c.className = "tl-cell past";
					c.innerHTML = "<span>Terlewat</span>";
				} else if (bk) {
					const cls = STATUS_CLASS[bk.status] || "approved";
					if (cls === "approved") approved++;
					else pending++;
					c.className = "tl-cell " + cls;
					c.innerHTML = `<span class="tl-pic">${bk.pic_name}</span><span class="tl-agenda">${bk.agenda}</span><span class="tl-status">${bk.status}</span>`;
					c.tabIndex = 0;
					c.addEventListener("click", () => openDetail(room, slot, bk));
				} else {
					available++;
					c.className = "tl-cell available";
					c.innerHTML = '<span class="tl-plus">+</span><span>Booking</span>';
					c.tabIndex = 0;
					c.addEventListener("click", () =>
						openBookingModal(room.id, slot.label),
					);
				}
				el.appendChild(c);
			});
		});

		document.getElementById("statAvailable").textContent = available;
		document.getElementById("statBooked").textContent = approved + pending;
	}

	// ---------- DATE NAVIGATION ----------
	const datePicker = document.getElementById("datePicker");

	function loadTimeline(dateISO) {
		fetch(`${BASE}/dashboard/get_timeline?date=${dateISO}`)
			.then((r) => r.json())
			.then((res) => {
				if (!res.success) return;
				currentDate = res.date;
				bookings = res.bookings;
				datePicker.value = currentDate;
				renderTimeline();
				history.replaceState(null, "", `${BASE}/dashboard?date=${currentDate}`);
			})
			.catch(() => showToast("Gagal memuat data. Periksa koneksi ke server."));
	}

	// ---------- LIVE AUTO-REFRESH ----------
	// Silently re-pulls the timeline for whichever date is currently on
	// screen, so a new booking submitted by someone else (or an
	// approve/reject decision) shows up on this dashboard without the
	// user having to reload the page. Deliberately quiet: no toast/error
	// noise on a failed poll, since this runs constantly in the background.
	const AUTO_REFRESH_MS = 6000;
	let autoRefreshTimer = null;
	let refreshInFlight = false;

	function refreshTimelineSilently() {
		if (refreshInFlight) return;
		refreshInFlight = true;
		fetch(`${BASE}/dashboard/get_timeline?date=${currentDate}`, {
			headers: { "X-Requested-With": "XMLHttpRequest" },
		})
			.then((r) => r.json())
			.then((res) => {
				if (!res.success || res.date !== currentDate) return;
				bookings = res.bookings;
				renderTimeline();
			})
			.catch(() => {
				/* network hiccup: try again next tick */
			})
			.finally(() => {
				refreshInFlight = false;
			});
	}

	function startAutoRefresh() {
		stopAutoRefresh();
		autoRefreshTimer = setInterval(refreshTimelineSilently, AUTO_REFRESH_MS);
	}
	function stopAutoRefresh() {
		if (autoRefreshTimer) clearInterval(autoRefreshTimer);
		autoRefreshTimer = null;
	}

	// Don't burn requests/battery on a hidden tab, but catch up immediately
	// the moment the user comes back to it.
	document.addEventListener("visibilitychange", () => {
		if (document.visibilityState === "visible") {
			refreshTimelineSilently();
			startAutoRefresh();
		} else {
			stopAutoRefresh();
		}
	});

	datePicker.addEventListener("change", (e) => loadTimeline(e.target.value));
	document
		.getElementById("todayBtn")
		.addEventListener("click", () => loadTimeline(todayISO()));
	document.getElementById("prevDay").addEventListener("click", () => {
		const d = new Date(currentDate + "T00:00:00");
		d.setDate(d.getDate() - 1);
		loadTimeline(toLocalISO(d));
	});
	document.getElementById("nextDay").addEventListener("click", () => {
		const d = new Date(currentDate + "T00:00:00");
		d.setDate(d.getDate() + 1);
		loadTimeline(toLocalISO(d));
	});

	// ---------- BOOKING MODAL ----------
	const modalOverlay = document.getElementById("modalOverlay");
	const roomSelect = document.getElementById("roomSelect");
	const slotGrid = document.getElementById("slotGrid");
	const bookingDate = document.getElementById("bookingDate");
	const agendaInput = document.getElementById("agendaInput");
	const modalError = document.getElementById("modalError");

	let selectedRoomId = null;
	let selectedSlots = new Set();

	function refreshRoomPills() {
		roomSelect.querySelectorAll(".room-pill").forEach((btn) => {
			btn.classList.toggle(
				"selected",
				String(btn.dataset.roomId) === String(selectedRoomId),
			);
		});
	}

	function refreshSlotChips() {
		slotGrid.querySelectorAll(".slot-chip").forEach((chip) => {
			const label = chip.dataset.slot;
			const bk = modalBookings[selectedRoomId + "|" + label];
			const taken = bk && bk.status !== "Ditolak";
			const slotObj = CFG.slots.find((s) => s.label === label);
			const past = isPastSlot(bookingDate.value, slotObj);
			const disabled = taken || past;
			chip.classList.toggle("disabled", disabled);
			chip.classList.toggle("selected", !disabled && selectedSlots.has(label));
			chip.disabled = disabled;
		});
	}

	function loadModalBookingsThenRefresh() {
		fetch(`${BASE}/dashboard/get_timeline?date=${bookingDate.value}`)
			.then((r) => r.json())
			.then((res) => {
				modalBookings = res.success ? res.bookings : {};
				refreshSlotChips();
			})
			.catch(() => {
				modalBookings = {};
				refreshSlotChips();
			});
	}

	roomSelect.querySelectorAll(".room-pill").forEach((btn) => {
		btn.addEventListener("click", () => {
			selectedRoomId = btn.dataset.roomId;
			selectedSlots.clear();
			refreshRoomPills();
			refreshSlotChips();
		});
	});

	slotGrid.querySelectorAll(".slot-chip").forEach((chip) => {
		chip.addEventListener("click", () => {
			if (chip.disabled) return;
			const label = chip.dataset.slot;
			selectedSlots.has(label)
				? selectedSlots.delete(label)
				: selectedSlots.add(label);
			refreshSlotChips();
		});
	});

	bookingDate.addEventListener("change", () => {
		selectedSlots.clear();
		loadModalBookingsThenRefresh();
	});

	function openBookingModal(roomId, slotLabel) {
		selectedRoomId = roomId ? String(roomId) : String(CFG.rooms[0].id);
		bookingDate.value = currentDate;
		selectedSlots = new Set(slotLabel ? [slotLabel] : []);
		agendaInput.value = "";
		modalError.textContent = "";
		refreshRoomPills();
		modalBookings = bookings; // same as currently-loaded date
		refreshSlotChips();
		modalOverlay.classList.add("open");
	}
	function closeBookingModal() {
		modalOverlay.classList.remove("open");
	}

	document
		.getElementById("modalClose")
		.addEventListener("click", closeBookingModal);
	document
		.getElementById("btnCancel")
		.addEventListener("click", closeBookingModal);
	modalOverlay.addEventListener("click", (e) => {
		if (e.target === modalOverlay) closeBookingModal();
	});

	document.getElementById("btnSubmit").addEventListener("click", () => {
		if (!selectedRoomId) {
			modalError.textContent = "Pilih ruangan terlebih dahulu.";
			return;
		}
		if (!bookingDate.value) {
			modalError.textContent = "Pilih tanggal terlebih dahulu.";
			return;
		}
		if (selectedSlots.size === 0) {
			modalError.textContent = "Pilih minimal satu jam.";
			return;
		}
		if (!agendaInput.value.trim()) {
			modalError.textContent = "Isi agenda meeting terlebih dahulu.";
			return;
		}

		modalError.textContent = "";
		const submitBtn = document.getElementById("btnSubmit");
		submitBtn.disabled = true;

		const slotsArr = Array.from(selectedSlots);
		let index = 0;

		function submitNext() {
			if (index >= slotsArr.length) {
				submitBtn.disabled = false;
				closeBookingModal();
				loadTimeline(bookingDate.value);
				showToast("Booking berhasil diajukan ✓ — menunggu konfirmasi");
				return;
			}
			const label = slotsArr[index];
			const body = new URLSearchParams({
				room_id: selectedRoomId,
				date: bookingDate.value,
				slot_label: label,
				agenda: agendaInput.value.trim(),
			});
			fetch(`${BASE}/dashboard/book`, {
				method: "POST",
				body,
				headers: { "X-Requested-With": "XMLHttpRequest" },
			})
				.then((r) => r.json())
				.then((res) => {
					if (!res.success) {
						submitBtn.disabled = false;
						modalError.textContent = res.message || "Gagal mengajukan booking.";
						return;
					}
					index++;
					submitNext();
				})
				.catch(() => {
					submitBtn.disabled = false;
					modalError.textContent = "Gagal terhubung ke server.";
				});
		}
		submitNext();
	});

	// ---------- DETAIL MODAL ----------
	const detailOverlay = document.getElementById("detailOverlay");
	const detailBody = document.getElementById("detailBody");
	const STATUS_BADGE_CLASS = {
		Disetujui: "badge-approved",
		Menunggu: "badge-pending",
		Ditolak: "badge-rejected",
	};

	function openDetail(room, slot, bk) {
		detailBody.innerHTML = `
      <p><b>Ruangan:</b> ${room.name} (${room.location})</p>
      <p><b>Tanggal:</b> ${fmtDateID(currentDate)}</p>
      <p><b>Jam:</b> ${slot.label}</p>
      <p><b>PIC:</b> ${bk.pic_name}</p>
      <p><b>Agenda:</b> ${bk.agenda}</p>
      <p><b>Status:</b> <span class="badge ${STATUS_BADGE_CLASS[bk.status]}"><span class="badge-dot"></span>${bk.status}</span></p>`;
		const rebookBtn = document.getElementById("detailRebookBtn");
		if (bk.status === "Ditolak") {
			rebookBtn.style.display = "inline-flex";
			rebookBtn.onclick = () => {
				closeDetail();
				openBookingModal(room.id, slot.label);
			};
		} else {
			rebookBtn.style.display = "none";
		}
		detailOverlay.classList.add("open");
	}
	function closeDetail() {
		detailOverlay.classList.remove("open");
	}
	document.getElementById("detailClose").addEventListener("click", closeDetail);
	document
		.getElementById("detailCloseBtn")
		.addEventListener("click", closeDetail);
	detailOverlay.addEventListener("click", (e) => {
		if (e.target === detailOverlay) closeDetail();
	});

	document.addEventListener("keydown", (e) => {
		if (e.key === "Escape") {
			closeBookingModal();
			closeDetail();
		}
	});

	// ---------- TOAST ----------
	let toastTimer;
	function showToast(msg) {
		const t = document.getElementById("toast");
		t.textContent = msg;
		t.classList.add("show");
		clearTimeout(toastTimer);
		toastTimer = setTimeout(() => t.classList.remove("show"), 2600);
	}
	window.showToast = showToast;

	// ---------- FULLSCREEN ----------
	const fullscreenBtn = document.getElementById("fullscreenBtn");
	const fullscreenLabel = document.getElementById("fullscreenLabel");
	fullscreenBtn.addEventListener("click", () => {
		if (!document.fullscreenElement) {
			document.documentElement
				.requestFullscreen()
				.catch(() => showToast("Browser tidak mengizinkan mode layar penuh."));
		} else {
			document.exitFullscreen();
		}
	});
	document.addEventListener("fullscreenchange", () => {
		fullscreenLabel.textContent = document.fullscreenElement
			? "Keluar Layar Penuh"
			: "Layar Penuh";
	});

	// ---------- INIT ----------
	renderTimeline();
	startAutoRefresh();
})();
