/**
 * notify.js
 * Polls the server every few seconds for new booking events and shows:
 *  - an in-page toast (reuses templates/footer.php's showToast())
 *  - a native browser/desktop notification (if the user allows it)
 *
 * Runs on every logged-in page (included from templates/footer.php), so
 * admins are alerted about new requests and users about approve/reject
 * decisions without having to open the Data Booking / Profile page first.
 */
(function () {
	var POLL_URL = window.RUANGTEMU_BASE_URL + "notify/poll";
	var POLL_INTERVAL_MS = 8000;
	var beepCtx = null;

	// Tracks which notifications this tab has already shown, keyed by the
	// server-provided stable id. Guards against the same event being shown
	// twice — whether from a server-side timing edge case, a page that
	// re-runs init(), or simply polling from more than one open tab.
	// sessionStorage (not a plain in-memory Set) so it also survives normal
	// navigation between pages within the same tab/session.
	var SHOWN_KEY = "ruangtemu_shown_notif_ids";

	function getShownIds() {
		try {
			return JSON.parse(sessionStorage.getItem(SHOWN_KEY) || "[]");
		} catch (e) {
			return [];
		}
	}

	function rememberShownId(id) {
		if (!id) return;
		var shown = getShownIds();
		shown.push(id);
		// Keep this list small; we only ever need to catch near-term repeats.
		if (shown.length > 200) shown = shown.slice(shown.length - 200);
		try {
			sessionStorage.setItem(SHOWN_KEY, JSON.stringify(shown));
		} catch (e) {
			/* ignore quota errors */
		}
	}

	function alreadyShown(id) {
		return !!id && getShownIds().indexOf(id) !== -1;
	}

	function playBeep() {
		try {
			beepCtx =
				beepCtx || new (window.AudioContext || window.webkitAudioContext)();
			var osc = beepCtx.createOscillator();
			var gain = beepCtx.createGain();
			osc.type = "sine";
			osc.frequency.value = 880;
			gain.gain.setValueAtTime(0.08, beepCtx.currentTime);
			gain.gain.exponentialRampToValueAtTime(0.001, beepCtx.currentTime + 0.35);
			osc.connect(gain).connect(beepCtx.destination);
			osc.start();
			osc.stop(beepCtx.currentTime + 0.35);
		} catch (e) {
			/* audio not available, ignore */
		}
	}

	function showDesktopNotification(n) {
		if (!("Notification" in window) || Notification.permission !== "granted")
			return;

		var notif = new Notification(n.title, {
			body: n.message,
			tag: n.type + "-" + n.message, // avoid stacking duplicates
		});

		notif.onclick = function () {
			window.focus();
			if (n.url) window.location.href = n.url;
			notif.close();
		};
		setTimeout(function () {
			notif.close();
		}, 8000);
	}

	function handleNotifications(list) {
		list.forEach(function (n) {
			if (alreadyShown(n.id)) return; // already shown this one — skip
			rememberShownId(n.id);
			if (typeof showToast === "function") showToast(n.message);
			playBeep();
			showDesktopNotification(n);
		});
	}

	function poll() {
		fetch(POLL_URL, {
			credentials: "same-origin",
			headers: { "X-Requested-With": "XMLHttpRequest" },
		})
			.then(function (res) {
				var ctype = res.headers.get("content-type") || "";
				if (!ctype.indexOf) return null;
				if (ctype.indexOf("application/json") === -1) return null; // e.g. redirected to /login
				return res.json();
			})
			.then(function (data) {
				if (
					data &&
					data.success &&
					data.notifications &&
					data.notifications.length
				) {
					handleNotifications(data.notifications);
				}
			})
			.catch(function () {
				/* network hiccup: skip this cycle silently */
			});
	}

	function init() {
		// Ask permission once, quietly (no custom UI) — most browsers only
		// require a user gesture for autoplay audio, not for this prompt.
		if ("Notification" in window && Notification.permission === "default") {
			Notification.requestPermission();
		}

		poll(); // prime the "since" cursor immediately
		setInterval(poll, POLL_INTERVAL_MS);

		// Also refresh right away whenever the tab becomes visible again.
		document.addEventListener("visibilitychange", function () {
			if (document.visibilityState === "visible") poll();
		});
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", init);
	} else {
		init();
	}
})();
