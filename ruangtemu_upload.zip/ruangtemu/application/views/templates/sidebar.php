<?php
$is_admin = isset($current_user['access_level']) && $current_user['access_level'] === 'admin';

$menu = array(
    array('key' => 'dashboard', 'url' => 'dashboard', 'label' => 'Dashboard', 'admin_only' => FALSE,
        'icon' => '<rect x="3" y="3" width="8" height="8" rx="1.5" stroke="currentColor" stroke-width="1.8"/><rect x="13" y="3" width="8" height="8" rx="1.5" stroke="currentColor" stroke-width="1.8"/><rect x="3" y="13" width="8" height="8" rx="1.5" stroke="currentColor" stroke-width="1.8"/><rect x="13" y="13" width="8" height="8" rx="1.5" stroke="currentColor" stroke-width="1.8"/>'),
    array('key' => 'booking', 'url' => 'booking', 'label' => 'Data Booking', 'admin_only' => TRUE,
        'icon' => '<path d="M4 6H20M4 12H20M4 18H14" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>'),
    array('key' => 'users', 'url' => 'users', 'label' => 'Data Users', 'admin_only' => TRUE,
        'icon' => '<circle cx="12" cy="8" r="3.2" stroke="currentColor" stroke-width="1.8"/><path d="M5 20c1.2-4 4.2-6 7-6s5.8 2 7 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>'),
    array('key' => 'rooms', 'url' => 'rooms', 'label' => 'Kelola Ruang', 'admin_only' => TRUE,
        'icon' => '<rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" stroke-width="1.8"/><path d="M3 9h18M9 21V9" stroke="currentColor" stroke-width="1.8"/>'),
    array('key' => 'profile', 'url' => 'profile', 'label' => 'Profile', 'admin_only' => FALSE,
        'icon' => '<circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8"/><path d="M12 8V12L14.5 14.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>'),
);
?>
<aside class="sidebar">
  <div class="brand">
    <div class="brand-mark">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="17" rx="3" stroke="currentColor" stroke-width="1.8"/><path d="M3 9H21" stroke="currentColor" stroke-width="1.8"/><path d="M8 2V6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M16 2V6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="8" cy="14" r="1.4" fill="currentColor"/><circle cx="12.5" cy="14" r="1.4" fill="currentColor"/></svg>
    </div>
    <div class="brand-text">
      <span class="brand-name">RuangTemu</span>
      <span class="brand-sub">Booking ruang meeting</span>
    </div>
  </div>

  <nav class="menu">
    <span class="menu-label">Menu</span>
    <?php foreach ($menu as $item):
      if ($item['admin_only'] && !$is_admin) continue;
    ?>
      <a class="menu-item<?php echo ($active_page === $item['key']) ? ' active' : ''; ?>" href="<?php echo base_url($item['url']); ?>">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><?php echo $item['icon']; ?></svg>
        <span><?php echo $item['label']; ?></span>
      </a>
    <?php endforeach; ?>
  </nav>

  <a class="menu-item logout" href="<?php echo base_url('logout'); ?>">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M16 17l5-5-5-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M21 12H9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
    <span>Logout</span>
  </a>
</aside>
