<?php /* $active_page and $current_user are available here too */ ?>
</div><!-- /.app -->

<div class="toast" id="toast"></div>

<script>
function showToast(msg) {
  var t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2600);
}
<?php $flash = $this->session->flashdata('toast'); ?>
<?php if (!empty($flash)): ?>
document.addEventListener('DOMContentLoaded', function () {
  showToast(<?php echo json_encode($flash); ?>);
});
<?php endif; ?>
</script>

<script>window.RUANGTEMU_BASE_URL = <?php echo json_encode(base_url()); ?>;</script>
<script src="<?php echo asset_url('assets/js/notify.js'); ?>"></script>
</body>
</html>
