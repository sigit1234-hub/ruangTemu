<?php
$avatar_initials = '';
if (!empty($current_user['name'])) {
    $parts = explode(' ', trim($current_user['name']));
    $avatar_initials = strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
}
?>
<header class="topbar">
  <div>
    <h1><?php echo isset($topbar_title) ? $topbar_title : ''; ?></h1>
    <p class="muted"><?php echo isset($topbar_subtitle) ? $topbar_subtitle : ''; ?></p>
  </div>
  <div class="profile-chip">
    <div class="avatar" style="background:var(--brand); width:34px; height:34px; font-size:12px;"><?php echo $avatar_initials; ?></div>
    <div>
      <span class="profile-name"><?php echo html_escape($current_user['name']); ?></span>
      <span class="profile-role"><?php echo html_escape($current_user['department']); ?></span>
    </div>
  </div>
</header>
