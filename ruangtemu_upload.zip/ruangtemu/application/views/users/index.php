<main class="main">

    <?php
    $this->load->view('templates/topbar', array(
        'topbar_title' => 'Data Users',
        'topbar_subtitle' => 'Pengguna yang terdaftar di RuangTemu',
        'current_user' => $current_user
    ));
    ?>

    <section class="stats">
        <div class="stat-card">
            <span class="stat-num"><?php echo $total; ?></span>
            <span class="stat-label">Total pengguna</span>
        </div>
        <div class="stat-card">
            <span class="stat-num"><?php echo $stat_active; ?></span>
            <span class="stat-label">Aktif</span>
        </div>
        <div class="stat-card">
            <span class="stat-num"><?php echo count($departments); ?></span>
            <span class="stat-label">Departemen</span>
        </div>
    </section>

    <form method="get" action="<?php echo base_url('users'); ?>" class="filter-bar">
        <div class="search-input">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8" />
                <path d="M21 21L16.5 16.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" />
            </svg>
            <input type="text" name="q" placeholder="Cari nama atau email..."
                value="<?php echo html_escape($filters['q']); ?>">
        </div>
        <select class="filter-select" name="department" onchange="this.form.submit()">
            <option value="">Semua departemen</option>
            <?php foreach ($departments as $dept): ?>
            <option value="<?php echo html_escape($dept); ?>"
                <?php echo ($filters['department'] === $dept) ? 'selected' : ''; ?>><?php echo html_escape($dept); ?>
            </option>
            <?php endforeach; ?>
        </select>
        <select class="filter-select" name="status" onchange="this.form.submit()">
            <option value="">Semua status</option>
            <option value="Aktif" <?php echo ($filters['status'] === 'Aktif') ? 'selected' : ''; ?>>Aktif</option>
            <option value="Nonaktif" <?php echo ($filters['status'] === 'Nonaktif') ? 'selected' : ''; ?>>Nonaktif
            </option>
        </select>
        <button type="submit" class="btn-ghost">Cari</button>
        <button type="button" class="btn-primary" id="btnAddUser"
            style="display:inline-flex; align-items:center; gap:6px;">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                <path d="M12 5V19M5 12H19" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
            </svg>
            Tambah User
        </button>
    </form>

    <div class="table-card">
        <div class="table-scroll">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Departemen</th>
                        <th>ID User</th>
                        <th>Hak Akses</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="7">
                            <div class="empty-state">
                                <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
                                    <circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.5" />
                                    <path d="M4 20c1.5-5 5-7.5 8-7.5s6.5 2.5 8 7.5" stroke="currentColor"
                                        stroke-width="1.5" />
                                </svg>
                                <p>Tidak ada pengguna yang cocok dengan filter ini.</p>
                            </div>
                        </td>
                    </tr>
                    <?php else: foreach ($users as $u):
                        $initials = strtoupper(mb_substr($u['name'], 0, 1));
                        $is_admin_row = $u['access_level'] === 'admin';
                        ?>
                    <tr>
                        <td>
                            <div class="person-cell">
                                <div class="avatar" style="background:#12A594;"><?php echo $initials; ?></div>
                                <div class="person-name"><?php echo html_escape($u['name']); ?></div>
                            </div>
                        </td>
                        <td><span class="badge badge-role"><?php echo html_escape($u['department']); ?></span></td>
                        <td class="cell-muted"><?php echo html_escape($u['email']); ?></td>
                        <td><span class="badge <?php echo $is_admin_row ? 'badge-admin' : 'badge-role'; ?>"><span
                                    class="badge-dot"></span><?php echo $is_admin_row ? 'Admin' : 'User Biasa'; ?></span>
                        </td>
                        <td><span
                                class="badge <?php echo ($u['status'] === 'Aktif') ? 'badge-active' : 'badge-inactive'; ?>"><span
                                    class="badge-dot"></span><?php echo $u['status']; ?></span></td>
                        <td>
                            <div class="row-actions">
                                <?php if ((int) $u['id'] !== (int) $current_user['id']): ?>
                                <a class="row-btn"
                                    title="<?php echo $is_admin_row ? 'Jadikan User Biasa' : 'Jadikan Admin'; ?>"
                                    href="<?php echo base_url('users/toggle_access/' . $u['id']); ?>"
                                    onclick="return confirm('<?php echo $is_admin_row ? 'Cabut hak akses admin dari' : 'Jadikan admin:'; ?> <?php echo html_escape($u['name']); ?>?');">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                                        <path d="M12 2l2.5 5.5L20 8.5l-4 4 1 6-5-2.7L7 18.5l1-6-4-4 5.5-1L12 2z"
                                            stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" />
                                    </svg>
                                </a>
                                <?php endif; ?>
                                <a class="row-btn"
                                    title="<?php echo ($u['status'] === 'Aktif') ? 'Nonaktifkan' : 'Aktifkan'; ?>"
                                    href="<?php echo base_url('users/toggle/' . $u['id']); ?>">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                                        <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.6" />
                                        <path d="M12 7V12L15 14" stroke="currentColor" stroke-width="1.6"
                                            stroke-linecap="round" />
                                    </svg>
                                </a>
                                <?php if ((int) $u['id'] !== (int) $current_user['id']): ?>
                                <a class="row-btn danger" title="Hapus user"
                                    href="<?php echo base_url('users/delete/' . $u['id']); ?>"
                                    onclick="return confirm('Hapus user ini?');">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                                        <path
                                            d="M4 7h16M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2m2 0v13a1 1 0 01-1 1H8a1 1 0 01-1-1V7h10z"
                                            stroke="currentColor" stroke-width="1.6" stroke-linecap="round" />
                                    </svg>
                                </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <div class="table-foot">
            <span>Menampilkan <?php echo count($users); ?> dari <?php echo $total; ?> data</span>
            <div class="pagination">
                <?php for ($i = 1; $i <= $total_pages; $i++):
                    $qs = array_merge($filters, array('page' => $i)); ?>
                <a href="<?php echo base_url('users?' . http_build_query($qs)); ?>"
                    class="page-btn <?php echo ($i === $page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
        </div>
    </div>

</main>

<!-- MODAL: add user -->
<div class="modal-overlay" id="modalOverlay">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
        <div class="modal-head">
            <h2 id="modalTitle">Tambah User</h2>
            <button class="modal-close" id="modalClose" aria-label="Tutup">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M6 6L18 18M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                </svg>
            </button>
        </div>
        <form method="post" action="<?php echo base_url('users/add'); ?>">
            <div class="modal-body">
                <div class="field">
                    <label>Nama Lengkap</label>
                    <div class="input-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                            <circle cx="12" cy="8" r="3.2" stroke="currentColor" stroke-width="1.8" />
                            <path d="M5 20c1.2-4 4.2-6 7-6s5.8 2 7 6" stroke="currentColor" stroke-width="1.8"
                                stroke-linecap="round" />
                        </svg>
                        <input type="text" name="name" placeholder="Nama lengkap" required>
                    </div>
                </div>
                <div class="field">
                    <label>Fungsi / Tim</label>
                    <div class="input-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                            <rect x="4" y="3" width="16" height="18" rx="2" stroke="currentColor" stroke-width="1.8" />
                            <path d="M8 8H16M8 12H16M8 16H12" stroke="currentColor" stroke-width="1.6"
                                stroke-linecap="round" />
                        </svg>
                        <input type="text" name="department" placeholder="Contoh: SGO / PVA / SPM" required>
                    </div>
                </div>
                <div class="field">
                    <label>ID User</label>
                    <div class="input-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                            <path
                                d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0 2c-4.42 0-8 2.24-8 5v1h16v-1c0-2.76-3.58-5-8-5z"
                                fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                        <input type="text" name="userId" placeholder="Nama dan Tim" required>
                    </div>
                </div>
                <p class="form-note">Password default untuk user baru: <b>password123</b> (bisa diganti oleh user
                    tersebut lewat halaman Profile).</p>
            </div>
            <div class="modal-foot">
                <button type="button" class="btn-secondary" id="btnCancel">Batal</button>
                <button type="submit" class="btn-primary">Simpan User</button>
            </div>
        </form>
    </div>
</div>

<script src="<?php echo asset_url('assets/js/users.js'); ?>"></script>