<main class="main">

    <?php
    $this->load->view('templates/topbar', array(
        'topbar_title' => 'Profile',
        'topbar_subtitle' => 'Detail data diri dan riwayat peminjaman ruang Anda',
        'current_user' => $current_user
    ));

    $initials = '';
    $parts = explode(' ', trim($current_user['name']));
    $initials = strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
    ?>

    <?php if (!empty($profile_success)): ?>
    <div class="alert-banner alert-success"><?php echo html_escape($profile_success); ?></div>
    <?php endif; ?>
    <?php if (!empty($profile_error)): ?>
    <div class="alert-banner alert-error"><?php echo $profile_error; ?></div>
    <?php endif; ?>

    <div class="profile-grid">

        <!-- LEFT: employee detail card -->
        <div class="profile-card">
            <div class="profile-avatar-lg"><?php echo $initials; ?></div>
            <h3><?php echo html_escape($current_user['name']); ?></h3>
            <p><?php echo html_escape($current_user['role']); ?> ·
                <?php echo html_escape($current_user['department']); ?></p>

            <div class="profile-meta">
                <div class="profile-meta-row"><span>User
                        ID</span><span><?php echo html_escape($current_user['email']); ?></span></div>
                <div class="profile-meta-row"><span>Fungsi /
                        Tim</span><span><?php echo html_escape($current_user['department']); ?></span></div>
                <div class="profile-meta-row"><span>Status</span>
                    <span><span
                            class="badge <?php echo ($current_user['status'] === 'Aktif') ? 'badge-active' : 'badge-inactive'; ?>"><span
                                class="badge-dot"></span><?php echo $current_user['status']; ?></span></span>
                </div>
                <div class="profile-meta-row"><span>Bergabung
                        sejak</span><span><?php echo date('d M Y', strtotime($current_user['created_at'])); ?></span>
                </div>
            </div>
        </div>

        <!-- RIGHT: update form -->
        <div class="form-card">
            <h3>Perbarui Data Diri</h3>
            <form method="post" action="<?php echo base_url('profile/update'); ?>">
                <div class="field-row">
                    <div class="field">
                        <label>Nama Lengkap</label>
                        <div class="input-icon">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                                <circle cx="12" cy="8" r="3.2" stroke="currentColor" stroke-width="1.8" />
                                <path d="M5 20c1.2-4 4.2-6 7-6s5.8 2 7 6" stroke="currentColor" stroke-width="1.8"
                                    stroke-linecap="round" />
                            </svg>
                            <input type="text" name="name" value="<?php echo html_escape($current_user['name']); ?>"
                                required>
                        </div>
                    </div>
                    <div class="field">
                        <label>Fungsi / Tim</label>
                        <div class="input-icon">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                                <rect x="4" y="3" width="16" height="18" rx="2" stroke="currentColor"
                                    stroke-width="1.8" />
                                <path d="M8 8H16M8 12H16M8 16H12" stroke="currentColor" stroke-width="1.6"
                                    stroke-linecap="round" />
                            </svg>
                            <input type="text" name="department"
                                value="<?php echo html_escape($current_user['department']); ?>" required>
                        </div>
                    </div>
                    <div class="field">
                        <label>User ID</label>
                        <div class="input-icon">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                                <circle cx="12" cy="8" r="3.2" stroke="currentColor" stroke-width="1.8" />
                                <path d="M5 20c1.2-4 4.2-6 7-6s5.8 2 7 6" stroke="currentColor" stroke-width="1.8"
                                    stroke-linecap="round" />
                            </svg>
                            <input type="hidden" name="email" value="<?php echo html_escape($current_user['email']); ?>"
                                required>
                            <input type="text" name="tes" value="<?php echo html_escape($current_user['email']); ?>"
                                required disabled>
                        </div>
                    </div>
                </div>
                <hr class="form-divider">
                <p class="form-note">Kosongkan bagian ini jika Anda tidak ingin mengganti password.</p>
                <div class="field-row">
                    <div class="field">
                        <label>Password Baru</label>
                        <div class="input-icon">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                                <rect x="4" y="10" width="16" height="10" rx="2" stroke="currentColor"
                                    stroke-width="1.8" />
                                <path d="M7 10V7a5 5 0 0110 0v3" stroke="currentColor" stroke-width="1.8" />
                            </svg>
                            <input type="password" name="new_password" placeholder="Minimal 6 karakter">
                        </div>
                    </div>
                    <div class="field">
                        <label>Konfirmasi Password</label>
                        <div class="input-icon">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                                <rect x="4" y="10" width="16" height="10" rx="2" stroke="currentColor"
                                    stroke-width="1.8" />
                                <path d="M7 10V7a5 5 0 0110 0v3" stroke="currentColor" stroke-width="1.8" />
                            </svg>
                            <input type="password" name="confirm_password" placeholder="Ulangi password baru">
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-primary" style="margin-top:6px;">Simpan Perubahan</button>
            </form>
        </div>
    </div>

    <!-- Booking history -->
    <div class="table-card" style="margin-top:20px;">
        <div style="padding:18px 18px 4px;">
            <h3 style="font-family:var(--font-display); margin:0; font-size:16px; color:var(--navy);">Riwayat Peminjaman
                Ruang Saya</h3>
        </div>
        <div class="table-scroll">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Ruangan</th>
                        <th>Tanggal</th>
                        <th>Jam</th>
                        <th>Agenda</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($my_bookings)): ?>
                    <tr>
                        <td colspan="5">
                            <div class="empty-state">
                                <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
                                    <rect x="3" y="4" width="18" height="17" rx="2" stroke="currentColor"
                                        stroke-width="1.5" />
                                    <path d="M8 2v4M16 2v4M3 9h18" stroke="currentColor" stroke-width="1.5" />
                                </svg>
                                <p>Anda belum pernah mengajukan booking ruang meeting.</p>
                            </div>
                        </td>
                    </tr>
                    <?php else: foreach ($my_bookings as $b):
                        $badgeClass = $b['status'] === 'Disetujui' ? 'badge-approved' : ($b['status'] === 'Menunggu' ? 'badge-pending' : 'badge-rejected');
                        ?>
                    <tr>
                        <td class="cell-primary"><?php echo html_escape($b['room_name']); ?> <span class="cell-muted">—
                                <?php echo html_escape($b['room_location']); ?></span></td>
                        <td class="cell-mono"><?php echo date('d M Y', strtotime($b['booking_date'])); ?></td>
                        <td class="cell-mono"><?php echo html_escape($b['slot_label']); ?></td>
                        <td><?php echo html_escape($b['agenda']); ?></td>
                        <td><span class="badge <?php echo $badgeClass; ?>"><span
                                    class="badge-dot"></span><?php echo $b['status']; ?></span></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</main>