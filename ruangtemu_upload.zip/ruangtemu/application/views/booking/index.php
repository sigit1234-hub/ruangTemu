<main class="main">

  <?php
    $this->load->view('templates/topbar', array(
        'topbar_title' => 'Data Booking',
        'topbar_subtitle' => 'Semua pengajuan booking ruang meeting',
        'current_user' => $current_user
    ));
  ?>

  <section class="stats">
    <div class="stat-card">
      <span class="stat-num"><?php echo $total; ?></span>
      <span class="stat-label">Total pengajuan</span>
    </div>
    <div class="stat-card">
      <span class="stat-num"><?php echo $stat_approved; ?></span>
      <span class="stat-label">Disetujui</span>
    </div>
    <div class="stat-card">
      <span class="stat-num"><?php echo $stat_pending; ?></span>
      <span class="stat-label">Menunggu konfirmasi</span>
    </div>
  </section>

  <form method="get" action="<?php echo base_url('booking'); ?>" class="filter-bar">
    <div class="search-input">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="M21 21L16.5 16.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
      <input type="text" name="q" placeholder="Cari nama PIC atau agenda..." value="<?php echo html_escape($filters['q']); ?>">
    </div>
    <select class="filter-select" name="room_id" onchange="this.form.submit()">
      <option value="">Semua ruangan</option>
      <?php foreach ($rooms as $room): ?>
        <option value="<?php echo $room['id']; ?>" <?php echo ((string) $filters['room_id'] === (string) $room['id']) ? 'selected' : ''; ?>><?php echo html_escape($room['name']); ?></option>
      <?php endforeach; ?>
    </select>
    <select class="filter-select" name="status" onchange="this.form.submit()">
      <option value="">Semua status</option>
      <?php foreach (array('Disetujui', 'Menunggu', 'Ditolak') as $s): ?>
        <option value="<?php echo $s; ?>" <?php echo ($filters['status'] === $s) ? 'selected' : ''; ?>><?php echo $s; ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn-ghost">Cari</button>
    <a href="<?php echo base_url('dashboard'); ?>" class="btn-primary" style="text-decoration:none; display:inline-flex; align-items:center; gap:6px;">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M12 5V19M5 12H19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
      Ajukan Booking Baru
    </a>
  </form>

  <div class="table-card">
    <div class="table-scroll">
      <table class="data-table">
        <thead>
          <tr>
            <th>PIC</th><th>Ruangan</th><th>Tanggal</th><th>Jam</th><th>Agenda</th><th>Status</th><th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($bookings)): ?>
            <tr><td colspan="7">
              <div class="empty-state">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="17" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M8 2v4M16 2v4M3 9h18" stroke="currentColor" stroke-width="1.5"/></svg>
                <p>Tidak ada data booking yang cocok dengan filter ini.</p>
              </div>
            </td></tr>
          <?php else: foreach ($bookings as $b):
            $badgeClass = $b['status'] === 'Disetujui' ? 'badge-approved' : ($b['status'] === 'Menunggu' ? 'badge-pending' : 'badge-rejected');
            $initials = strtoupper(mb_substr($b['pic_name'], 0, 1));
          ?>
            <tr>
              <td>
                <div class="person-cell">
                  <div class="avatar" style="background:#4B4FE0;"><?php echo $initials; ?></div>
                  <div>
                    <div class="person-name"><?php echo html_escape($b['pic_name']); ?></div>
                    <div class="person-sub"><?php echo html_escape($b['pic_dept']); ?></div>
                  </div>
                </div>
              </td>
              <td class="cell-primary"><?php echo html_escape($b['room_name']); ?></td>
              <td class="cell-mono"><?php echo date('d M Y', strtotime($b['booking_date'])); ?></td>
              <td class="cell-mono"><?php echo html_escape($b['slot_label']); ?></td>
              <td><?php echo html_escape($b['agenda']); ?></td>
              <td><span class="badge <?php echo $badgeClass; ?>"><span class="badge-dot"></span><?php echo $b['status']; ?></span></td>
              <td>
                <div class="row-actions">
                  <?php if ($b['status'] === 'Menunggu'): ?>
                    <a class="row-btn" title="Setujui" href="<?php echo base_url('booking/approve/' . $b['id']); ?>">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M4 12L9.5 17.5L20 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </a>
                    <a class="row-btn danger" title="Tolak" href="<?php echo base_url('booking/reject/' . $b['id']); ?>">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M6 6L18 18M18 6L6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                    </a>
                  <?php else: ?>
                    <a class="row-btn danger" title="Batalkan" href="<?php echo base_url('booking/cancel/' . $b['id']); ?>">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M4 7h16M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2m2 0v13a1 1 0 01-1 1H8a1 1 0 01-1-1V7h10z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
                    </a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
    <div class="table-foot">
      <span>Menampilkan <?php echo count($bookings); ?> dari <?php echo $total; ?> data</span>
      <div class="pagination">
        <?php for ($i = 1; $i <= $total_pages; $i++):
          $qs = array_merge($filters, array('page' => $i)); ?>
          <a href="<?php echo base_url('booking?' . http_build_query($qs)); ?>" class="page-btn <?php echo ($i === $page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
        <?php endfor; ?>
      </div>
    </div>
  </div>

</main>
