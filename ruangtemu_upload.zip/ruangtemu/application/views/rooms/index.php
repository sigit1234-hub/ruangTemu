<main class="main">

  <?php
    $this->load->view('templates/topbar', array(
        'topbar_title' => 'Kelola Ruang & Jam',
        'topbar_subtitle' => 'Atur daftar ruangan dan pilihan jam booking',
        'current_user' => $current_user
    ));
  ?>

  <!-- ROOMS -->
  <div class="table-card" style="margin-bottom:22px;">
    <div style="display:flex; align-items:center; justify-content:space-between; padding:18px 18px 14px; flex-wrap:wrap; gap:10px;">
      <h3 style="font-family:var(--font-display); margin:0; font-size:16px; color:var(--navy);">Ruangan</h3>
      <button type="button" class="btn-primary" id="btnAddRoom" style="display:inline-flex; align-items:center; gap:6px;">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M12 5V19M5 12H19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
        Tambah Ruangan
      </button>
    </div>
    <div class="table-scroll">
      <table class="data-table">
        <thead><tr><th>Nama Ruangan</th><th>Lokasi</th><th>Kapasitas</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php if (empty($rooms)): ?>
            <tr><td colspan="4"><div class="empty-state"><p>Belum ada ruangan.</p></div></td></tr>
          <?php else: foreach ($rooms as $r): ?>
            <tr>
              <td class="cell-primary"><?php echo html_escape($r['name']); ?></td>
              <td class="cell-muted"><?php echo html_escape($r['location']); ?></td>
              <td class="cell-mono"><?php echo (int) $r['capacity']; ?> orang</td>
              <td>
                <div class="row-actions">
                  <button type="button" class="row-btn" title="Edit"
                    data-edit-room
                    data-id="<?php echo $r['id']; ?>"
                    data-name="<?php echo html_escape($r['name']); ?>"
                    data-location="<?php echo html_escape($r['location']); ?>"
                    data-capacity="<?php echo (int) $r['capacity']; ?>">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M4 20h4l10-10-4-4L4 16v4z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>
                  </button>
                  <a class="row-btn danger" title="Hapus" href="<?php echo base_url('rooms/delete_room/' . $r['id']); ?>" onclick="return confirm('Hapus ruangan ini?');">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M4 7h16M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2m2 0v13a1 1 0 01-1 1H8a1 1 0 01-1-1V7h10z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- TIME SLOTS -->
  <div class="table-card">
    <div style="display:flex; align-items:center; justify-content:space-between; padding:18px 18px 14px; flex-wrap:wrap; gap:10px;">
      <h3 style="font-family:var(--font-display); margin:0; font-size:16px; color:var(--navy);">Pilihan Jam Booking</h3>
      <button type="button" class="btn-primary" id="btnAddSlot" style="display:inline-flex; align-items:center; gap:6px;">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M12 5V19M5 12H19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
        Tambah Jam
      </button>
    </div>
    <div class="table-scroll">
      <table class="data-table">
        <thead><tr><th>Jam</th><th>Jam Mulai</th><th>Jam Selesai</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php if (empty($slots)): ?>
            <tr><td colspan="4"><div class="empty-state"><p>Belum ada pilihan jam.</p></div></td></tr>
          <?php else: foreach ($slots as $s): ?>
            <tr>
              <td class="cell-mono cell-primary"><?php echo html_escape($s['label']); ?></td>
              <td class="cell-mono"><?php echo sprintf('%02d:00', $s['start_hour']); ?></td>
              <td class="cell-mono"><?php echo sprintf('%02d:00', $s['end_hour']); ?></td>
              <td>
                <div class="row-actions">
                  <button type="button" class="row-btn" title="Edit"
                    data-edit-slot
                    data-id="<?php echo $s['id']; ?>"
                    data-start="<?php echo (int) $s['start_hour']; ?>"
                    data-end="<?php echo (int) $s['end_hour']; ?>">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M4 20h4l10-10-4-4L4 16v4z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>
                  </button>
                  <a class="row-btn danger" title="Hapus" href="<?php echo base_url('rooms/delete_slot/' . $s['id']); ?>" onclick="return confirm('Hapus pilihan jam ini?');">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M4 7h16M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2m2 0v13a1 1 0 01-1 1H8a1 1 0 01-1-1V7h10z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</main>

<!-- MODAL: add/edit room -->
<div class="modal-overlay" id="roomModal">
  <div class="modal" role="dialog" aria-modal="true">
    <div class="modal-head">
      <h2 id="roomModalTitle">Tambah Ruangan</h2>
      <button type="button" class="modal-close" id="roomModalClose" aria-label="Tutup">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M6 6L18 18M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
      </button>
    </div>
    <form method="post" id="roomForm" action="<?php echo base_url('rooms/add_room'); ?>">
      <div class="modal-body">
        <div class="field">
          <label>Nama Ruangan</label>
          <div class="input-icon">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="17" rx="2" stroke="currentColor" stroke-width="1.8"/></svg>
            <input type="text" name="name" id="roomName" placeholder="Contoh: Ruang Rapat Lt.5" required>
          </div>
        </div>
        <div class="field">
          <label>Lokasi</label>
          <div class="input-icon">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 21s7-6.5 7-11a7 7 0 10-14 0c0 4.5 7 11 7 11z" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="10" r="2.3" stroke="currentColor" stroke-width="1.6"/></svg>
            <input type="text" name="location" id="roomLocation" placeholder="Contoh: Kantor B Lt.5" required>
          </div>
        </div>
        <div class="field">
          <label>Kapasitas (orang)</label>
          <div class="input-icon">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="9" cy="8" r="3" stroke="currentColor" stroke-width="1.6"/><path d="M2 20c1-3.5 3.5-5.5 7-5.5s6 2 7 5.5" stroke="currentColor" stroke-width="1.6"/><circle cx="17" cy="8" r="2.4" stroke="currentColor" stroke-width="1.6"/></svg>
            <input type="number" name="capacity" id="roomCapacity" min="1" placeholder="Contoh: 10" required>
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" id="roomModalCancel">Batal</button>
        <button type="submit" class="btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- MODAL: add/edit slot -->
<div class="modal-overlay" id="slotModal">
  <div class="modal modal-sm" role="dialog" aria-modal="true">
    <div class="modal-head">
      <h2 id="slotModalTitle">Tambah Jam</h2>
      <button type="button" class="modal-close" id="slotModalClose" aria-label="Tutup">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M6 6L18 18M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
      </button>
    </div>
    <form method="post" id="slotForm" action="<?php echo base_url('rooms/add_slot'); ?>">
      <div class="modal-body">
        <div class="field-row">
          <div class="field">
            <label>Jam Mulai</label>
            <select name="start_hour" id="slotStart" class="filter-select" style="width:100%;" required>
              <?php for ($h = 0; $h <= 23; $h++): ?>
                <option value="<?php echo $h; ?>"><?php echo sprintf('%02d:00', $h); ?></option>
              <?php endfor; ?>
            </select>
          </div>
          <div class="field">
            <label>Jam Selesai</label>
            <select name="end_hour" id="slotEnd" class="filter-select" style="width:100%;" required>
              <?php for ($h = 1; $h <= 24; $h++): ?>
                <option value="<?php echo $h; ?>"><?php echo sprintf('%02d:00', $h); ?></option>
              <?php endfor; ?>
            </select>
          </div>
        </div>
        <p class="form-note">Label jam (mis. 08.00-10.00) dibuat otomatis dari jam mulai &amp; selesai.</p>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" id="slotModalCancel">Batal</button>
        <button type="submit" class="btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>

<script src="<?php echo asset_url('assets/js/rooms.js'); ?>"></script>
