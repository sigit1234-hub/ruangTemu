<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk — RuangTemu</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="<?php echo asset_url('assets/css/style.css'); ?>">
</head>

<body>
    <div class="login-page">
        <div class="login-card">
            <div class="login-brand">
                <div class="brand-mark">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                        <rect x="3" y="4" width="18" height="17" rx="3" stroke="currentColor" stroke-width="1.8" />
                        <path d="M3 9H21" stroke="currentColor" stroke-width="1.8" />
                        <path d="M8 2V6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" />
                        <path d="M16 2V6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" />
                        <circle cx="8" cy="14" r="1.4" fill="currentColor" />
                        <circle cx="12.5" cy="14" r="1.4" fill="currentColor" />
                    </svg>
                </div>
                <div class="brand-text">
                    <span class="brand-name">RuangTemu</span>
                    <span class="brand-sub">Booking ruang meeting</span>
                </div>
            </div>

            <p class="login-title">Masuk ke akun Anda</p>
            <p class="login-sub">Gunakan User ID dan password yang terdaftar.</p>

            <?php if (!empty($error)): ?>
            <div class="login-alert"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="post" action="<?php echo base_url('login'); ?>">
                <div class="field">
                    <label>ID User</label>
                    <div class="input-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                            <circle cx="12" cy="8" r="3.2" stroke="currentColor" stroke-width="1.8" />
                            <path d="M5 20c1.2-4 4.2-6 7-6s5.8 2 7 6" stroke="currentColor" stroke-width="1.8"
                                stroke-linecap="round" />
                        </svg>
                        <input type="text" name="alias" placeholder="ID User" required
                            value="<?php echo set_value('alias'); ?>">
                    </div>
                </div>
                <div class="field" style="margin-top:14px;">
                    <label>Password</label>
                    <div class="input-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                            <rect x="4" y="10" width="16" height="10" rx="2" stroke="currentColor" stroke-width="1.8" />
                            <path d="M7 10V7a5 5 0 0110 0v3" stroke="currentColor" stroke-width="1.8" />
                        </svg>
                        <input type="password" name="password" placeholder="••••••••" required>
                    </div>
                </div>
                <button type="submit" class="btn-primary" style="width:100%; margin-top:20px;">Masuk</button>
            </form>

            <p class="login-hint">CISO Office Group</p>
        </div>
    </div>
</body>

</html>