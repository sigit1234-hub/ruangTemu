<main class="main">

    <?php
    date_default_timezone_set('Asia/Jakarta');
    $topbar_title = 'Booking Ruang Meeting';
    $topbar_subtitle = 'Tanggal: ' . date('d F Y', strtotime($date));
    $this->load->view('templates/topbar', array(
        'topbar_title' => $topbar_title, 'topbar_subtitle' => $topbar_subtitle, 'current_user' => $current_user
    ));
    ?>

    <section class="stats">
        <div class="stat-card">
            <span class="stat-num" id="statAvailable">--</span>
            <span class="stat-label">Slot tersedia hari ini</span>
        </div>
        <div class="stat-card">
            <span class="stat-num" id="statBooked">--</span>
            <span class="stat-label">Slot terisi hari ini</span>
        </div>
        <div class="stat-card">
            <span class="stat-num"><?php echo count($rooms); ?></span>
            <span class="stat-label">Ruangan aktif</span>
        </div>
    </section>

    <section class="date-control">
        <div class="date-nav">
            <button id="prevDay" class="icon-btn" aria-label="Hari sebelumnya">‹</button>
            <input type="date" id="datePicker" value="<?php echo html_escape($date); ?>">
            <button id="nextDay" class="icon-btn" aria-label="Hari berikutnya">›</button>
        </div>
        <button id="todayBtn" class="btn-ghost">Hari ini</button>
        <button id="fullscreenBtn" class="btn-ghost" title="Tampilkan sebagai layar penuh">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style="vertical-align:-2px; margin-right:5px;">
                <path d="M4 9V5a1 1 0 011-1h4M15 4h4a1 1 0 011 1v4M20 15v4a1 1 0 01-1 1h-4M9 20H5a1 1 0 01-1-1v-4"
                    stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" />
            </svg><span id="fullscreenLabel">Layar Penuh</span>
        </button>
        <div class="legend">
            <span class="legend-item"><i class="dot dot-available"></i>Tersedia</span>
            <span class="legend-item"><i class="dot dot-approved"></i>Disetujui</span>
            <span class="legend-item"><i class="dot dot-pending"></i>Menunggu</span>
            <span class="legend-item"><i class="dot dot-rejected"></i>Ditolak</span>
            <span class="legend-item"><i class="dot dot-past"></i>Terlewat</span>
        </div>
    </section>

    <section class="timeline-card">
        <div class="timeline" id="timeline">
            <!-- rendered by dashboard.js -->
        </div>
    </section>

    <p class="hint">Klik langsung slot waktu pada tabel untuk mengajukan booking, atau lihat detail booking yang sudah
        ada.</p>

</main>

<!-- MODAL: New booking -->
<div class="modal-overlay" id="modalOverlay">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
        <div class="modal-head">
            <h2 id="modalTitle">Ajukan Booking</h2>
            <button class="modal-close" id="modalClose" aria-label="Tutup">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M6 6L18 18M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                </svg>
            </button>
        </div>
        <div class="modal-body">
            <div class="field">
                <label>Nama PIC</label>
                <div class="input-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <circle cx="12" cy="8" r="3.2" stroke="currentColor" stroke-width="1.8" />
                        <path d="M5 20c1.2-4 4.2-6 7-6s5.8 2 7 6" stroke="currentColor" stroke-width="1.8"
                            stroke-linecap="round" />
                    </svg>
                    <input type="text" id="picName" value="<?php echo html_escape($current_user['name']); ?>" readonly>
                </div>
            </div>
            <div class="field">
                <label>Ruangan</label>
                <div class="room-select" id="roomSelect">
                    <?php foreach ($rooms as $room): ?>
                    <button type="button" class="room-pill"
                        data-room-id="<?php echo $room['id']; ?>"><?php echo html_escape($room['name']); ?></button>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="field">
                <label>Tanggal</label>
                <div class="input-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <rect x="3" y="4" width="18" height="17" rx="2" stroke="currentColor" stroke-width="1.8" />
                        <path d="M3 9H21" stroke="currentColor" stroke-width="1.8" />
                    </svg>
                    <input type="date" id="bookingDate">
                </div>
            </div>
            <div class="field">
                <label>Jam <span class="muted-inline">(pilih satu atau lebih)</span></label>
                <div class="slot-grid" id="slotGrid">
                    <?php foreach ($slots as $slot): ?>
                    <button type="button" class="slot-chip" data-slot="<?php echo html_escape($slot['label']); ?>"
                        data-start="<?php echo $slot['start_hour']; ?>"
                        data-end="<?php echo $slot['end_hour']; ?>"><?php echo html_escape($slot['label']); ?></button>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="field">
                <label>Agenda</label>
                <textarea id="agendaInput" rows="2" placeholder="Contoh: Meeting koordinasi tim PVA"></textarea>
            </div>
            <div class="modal-error" id="modalError"></div>
        </div>
        <div class="modal-foot">
            <button class="btn-secondary" id="btnCancel">Batal</button>
            <button class="btn-primary" id="btnSubmit">Ajukan Booking</button>
        </div>
    </div>
</div>

<!-- MODAL: Booking detail -->
<div class="modal-overlay" id="detailOverlay">
    <div class="modal modal-sm" role="dialog" aria-modal="true">
        <div class="modal-head">
            <h2>Detail Booking</h2>
            <button class="modal-close" id="detailClose" aria-label="Tutup">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M6 6L18 18M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                </svg>
            </button>
        </div>
        <div class="modal-body" id="detailBody"></div>
        <div class="modal-foot">
            <button class="btn-secondary" id="detailCloseBtn">Tutup</button>
            <button class="btn-primary" id="detailRebookBtn" style="display:none;">Ajukan Ulang</button>
        </div>
    </div>
</div>

<script>
window.RUANGTEMU = {
    baseUrl: <?php echo json_encode(base_url()); ?>,
    date: <?php echo json_encode($date); ?>,
    rooms: <?php echo json_encode($rooms); ?>,
    slots: <?php echo json_encode($slots); ?>,
    bookings: <?php echo json_encode($bookings); ?>,
    currentUser: <?php echo json_encode(array('id' => $current_user['id'], 'name' => $current_user['name'])); ?>
};
</script>
<script src="<?php echo asset_url('assets/js/dashboard.js'); ?>"></script>