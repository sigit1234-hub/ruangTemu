<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Profile extends MY_Controller
{
    public function index()
    {
        // Already logged in? go straight to dashboard.
        if ($this->session->userdata('password') === "password123") {
            $this->session->set_flashdata('toast', 'Silahkan ubah password default');
        }

        $error = null;

        $data = array(
            'active_page' => 'profile',
            'profile_error' => $this->session->flashdata('profile_error'),
            'profile_success' => $this->session->flashdata('profile_success'),
            'my_bookings' => $this->Booking_model->get_by_user($this->user['id']),
        );

        $this->render('profile/index', $data);
    }

    /** POST /profile/update — updates name/email/phone/department (+ optional password change) */
    public function update()
    {
        $this->form_validation->set_rules('name', 'Nama Lengkap', 'required|max_length[100]');
        $this->form_validation->set_rules('department', 'Fungsi / Tim', 'required|max_length[60]');
        $this->form_validation->set_rules('email', 'UserId', 'required');

        // Only enforce email-uniqueness against OTHER users
        $email = $this->input->post('email', true);
        $existing = $this->User_model->get_by_email($email);
        if ($existing && (int) $existing['id'] !== (int) $this->user['id']) {
            $this->session->set_flashdata('profile_error', 'Email tersebut sudah dipakai oleh user lain.');
            redirect('profile');
            return;
        }

        if (!$this->form_validation->run()) {
            $this->session->set_flashdata('profile_error', strip_tags(validation_errors()));
            redirect('profile');
            return;
        }

        $this->User_model->update($this->user['id'], array(
            'name' => $this->input->post('name', true),
            'department' => $this->input->post('department', true),
            'email' => $email,
        ));

        // Optional password change
        $new_password = $this->input->post('new_password');
        $confirm_password = $this->input->post('confirm_password');
        if (!empty($new_password)) {
            if (strlen($new_password) < 6) {
                $this->session->set_flashdata('profile_error', 'Password baru minimal 6 karakter (data lain sudah tersimpan).');
                redirect('profile');
                return;
            }
            if ($new_password !== $confirm_password) {
                $this->session->set_flashdata('profile_error', 'Konfirmasi password tidak cocok (data lain sudah tersimpan).');
                redirect('profile');
                return;
            }
            $this->User_model->update_password($this->user['id'], $new_password);
        }
        $this->session->set_userdata('password', $new_password);
        $this->session->set_userdata('user_name', $this->input->post('name', true));
        $this->session->set_flashdata('profile_success', 'Profil berhasil diperbarui.');
        redirect('profile');
    }
}
