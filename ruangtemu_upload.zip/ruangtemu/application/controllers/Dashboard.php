<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends MY_Controller
{
    public function index()
    {
        if ($this->session->userdata('password') === "password123") {
            $this->session->set_flashdata('toast', 'Silahkan ubah password default');
            redirect('profile');
            return;
        }

        $date = $this->input->get('date') ?: date('Y-m-d');

        $data = array(
            'active_page' => 'dashboard',
            'rooms' => $this->Room_model->get_all(),
            'slots' => $this->Slot_model->get_all(),
            'date' => $date,
            'bookings' => $this->Booking_model->get_for_date($date),
        );

        $this->render('dashboard/index', $data);

    }

    /** AJAX: GET /dashboard/get_timeline?date=YYYY-MM-DD */
    public function get_timeline()
    {
        $date = $this->input->get('date') ?: date('Y-m-d');
        $bookings = $this->Booking_model->get_for_date($date);

        $this->json(array(
            'success' => true,
            'date' => $date,
            'bookings' => $bookings,
        ));
    }

    /** AJAX: POST /dashboard/book */
    public function book()
    {
        $this->form_validation->set_rules('room_id', 'Ruangan', 'required|integer');
        $this->form_validation->set_rules('date', 'Tanggal', 'required');
        $this->form_validation->set_rules('slot_label', 'Jam', 'required');
        $this->form_validation->set_rules('agenda', 'Agenda', 'required|max_length[255]');

        if (!$this->form_validation->run()) {
            $this->json(array('success' => false, 'message' => strip_tags(validation_errors())));
            return;
        }

        $room_id = (int) $this->input->post('room_id');
        $date = $this->input->post('date');
        $slot_label = $this->input->post('slot_label');
        $agenda = $this->input->post('agenda', true);

        $slot = null;
        foreach ($this->Slot_model->get_all() as $s) {
            if ($s['label'] === $slot_label) {
                $slot = $s;
                break;
            }
        }
        if (!$slot) {
            $this->json(array('success' => false, 'message' => 'Jam tidak valid.'));
            return;
        }

        $today = date('Y-m-d');
        $is_past_date = $date < $today;
        $is_past_slot_today = $date === $today && (int) $slot['end_hour'] <= (int) date('G');
        if ($is_past_date || $is_past_slot_today) {
            $this->json(array('success' => false, 'message' => 'Tidak bisa mengajukan booking untuk tanggal/jam yang sudah terlewat.'));
            return;
        }

        $result = $this->Booking_model->create(
            $this->user['id'],
            $room_id,
            $date,
            $slot['label'],
            $slot['start_hour'],
            $slot['end_hour'],
            $agenda
        );

        if ($result === true) {
            $this->json(array('success' => true, 'message' => 'Booking berhasil diajukan, menunggu konfirmasi.'));
        } else {
            $this->json(array('success' => false, 'message' => $result));
        }
    }
}
