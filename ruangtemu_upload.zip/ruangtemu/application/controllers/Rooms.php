<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rooms extends MY_Controller
{
    public function index()
    {
        $data = array(
            'active_page' => 'rooms',
            'rooms' => $this->Room_model->get_all(),
            'slots' => $this->Slot_model->get_all(),
        );
        $this->render('rooms/index', $data);
    }

    // ---------------- ROOMS ----------------

    public function add_room()
    {
        $this->form_validation->set_rules('name', 'Nama Ruangan', 'required|max_length[100]');
        $this->form_validation->set_rules('location', 'Lokasi', 'required|max_length[100]');
        $this->form_validation->set_rules('capacity', 'Kapasitas', 'required|integer|greater_than[0]');

        if ($this->form_validation->run()) {
            $this->Room_model->create(array(
                'name' => $this->input->post('name', TRUE),
                'location' => $this->input->post('location', TRUE),
                'capacity' => (int) $this->input->post('capacity'),
            ));
            $this->session->set_flashdata('toast', 'Ruangan berhasil ditambahkan.');
        } else {
            $this->session->set_flashdata('toast', strip_tags(validation_errors()));
        }
        redirect('rooms');
    }

    public function update_room($id)
    {
        $this->form_validation->set_rules('name', 'Nama Ruangan', 'required|max_length[100]');
        $this->form_validation->set_rules('location', 'Lokasi', 'required|max_length[100]');
        $this->form_validation->set_rules('capacity', 'Kapasitas', 'required|integer|greater_than[0]');

        if ($this->form_validation->run()) {
            $this->Room_model->update($id, array(
                'name' => $this->input->post('name', TRUE),
                'location' => $this->input->post('location', TRUE),
                'capacity' => (int) $this->input->post('capacity'),
            ));
            $this->session->set_flashdata('toast', 'Ruangan berhasil diperbarui.');
        } else {
            $this->session->set_flashdata('toast', strip_tags(validation_errors()));
        }
        redirect('rooms');
    }

    public function delete_room($id)
    {
        $count = $this->Room_model->count_bookings($id);
        if ($count > 0) {
            $this->session->set_flashdata('toast', "Tidak bisa menghapus: ruangan ini masih punya {$count} data booking.");
        } else {
            $this->Room_model->delete($id);
            $this->session->set_flashdata('toast', 'Ruangan dihapus.');
        }
        redirect('rooms');
    }

    // ---------------- TIME SLOTS ----------------

    public function add_slot()
    {
        $this->form_validation->set_rules('start_hour', 'Jam Mulai', 'required|integer|greater_than_equal_to[0]|less_than_equal_to[23]');
        $this->form_validation->set_rules('end_hour', 'Jam Selesai', 'required|integer|greater_than_equal_to[1]|less_than_equal_to[24]');

        if ($this->form_validation->run()) {
            $start = (int) $this->input->post('start_hour');
            $end = (int) $this->input->post('end_hour');
            if ($end <= $start) {
                $this->session->set_flashdata('toast', 'Jam selesai harus lebih besar dari jam mulai.');
            } else {
                $this->Slot_model->create($start, $end);
                $this->session->set_flashdata('toast', 'Jam booking berhasil ditambahkan.');
            }
        } else {
            $this->session->set_flashdata('toast', strip_tags(validation_errors()));
        }
        redirect('rooms');
    }

    public function update_slot($id)
    {
        $this->form_validation->set_rules('start_hour', 'Jam Mulai', 'required|integer|greater_than_equal_to[0]|less_than_equal_to[23]');
        $this->form_validation->set_rules('end_hour', 'Jam Selesai', 'required|integer|greater_than_equal_to[1]|less_than_equal_to[24]');

        if ($this->form_validation->run()) {
            $start = (int) $this->input->post('start_hour');
            $end = (int) $this->input->post('end_hour');
            if ($end <= $start) {
                $this->session->set_flashdata('toast', 'Jam selesai harus lebih besar dari jam mulai.');
            } else {
                $this->Slot_model->update($id, $start, $end);
                $this->session->set_flashdata('toast', 'Jam booking berhasil diperbarui.');
            }
        } else {
            $this->session->set_flashdata('toast', strip_tags(validation_errors()));
        }
        redirect('rooms');
    }

    public function delete_slot($id)
    {
        $this->Slot_model->delete($id);
        $this->session->set_flashdata('toast', 'Jam booking dihapus. Booking yang sudah ada dengan jam ini tidak terpengaruh.');
        redirect('rooms');
    }
}
