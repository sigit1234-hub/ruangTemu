<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Notify
 *
 * Lightweight polling endpoint (no extra DB tables needed) used by
 * assets/js/notify.js on every logged-in page:
 *
 *  - Admin  -> alerted when a new "Menunggu" (pending) booking request
 *              comes in, without needing to open the Data Booking page.
 *  - User   -> alerted when one of their own bookings gets approved
 *              ("Disetujui") or rejected ("Ditolak").
 *
 * A per-browser-session cursor (`notif_since`) tracks the last time this
 * user polled, so only *new* events since the previous check are returned.
 */
class Notify extends MY_Controller
{
    public function poll()
    {
        $since = $this->session->userdata('notif_since');
        $now = date('Y-m-d H:i:s');

        // First poll ever for this session: don't dump old history, just
        // start the clock from now.
        if (!$since) {
            $this->session->set_userdata('notif_since', $now);
            $this->json(array('success' => true, 'notifications' => array()));
            return;
        }

        $notifications = array();

        if ($this->user['access_level'] === 'admin') {
            $rows = $this->Booking_model->get_new_pending_since($since);

            foreach ($rows as $row) {
                $notifications[] = array(
                    'id' => 'pending-' . $row['id'],
                    'type' => 'new_booking',
                    'title' => 'Permohonan ruang baru',
                    'message' => $row['pic_name'] . ' mengajukan ' . $row['room_name']
                        . ' — ' . $row['booking_date'] . ' (' . $row['slot_label'] . ')',
                    'url' => site_url('booking'),
                );
            }
        } else {
            $rows = $this->Booking_model->get_status_changes_since($this->user['id'], $since);

            foreach ($rows as $row) {
                $decided = ($row['status'] === 'Disetujui') ? 'disetujui' : 'ditolak';
                $notifications[] = array(
                    'id' => 'status-' . $row['id'] . '-' . $row['status'] . '-' . strtotime($row['updated_at']),
                    'type' => 'status_change',
                    'title' => 'Update booking',
                    'message' => 'Booking ' . $row['room_name'] . ' (' . $row['booking_date']
                        . ', ' . $row['slot_label'] . ') telah ' . $decided . '.',
                    'url' => site_url('profile'),
                );
            }
        }

        $this->session->set_userdata('notif_since', $now);

        $this->json(array('success' => true, 'notifications' => $notifications));
    }
}
