<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Users extends MY_Controller
{
    private $per_page = 8;

    public function index()
    {
        $filters = array(
            'q' => $this->input->get('q'),
            'department' => $this->input->get('department'),
            'status' => $this->input->get('status'),
        );

        $page = max(1, (int) $this->input->get('page'));

        $total = $this->User_model->count_all($filters);
        $total_pages = max(1, (int) ceil($total / $this->per_page));
        $page = min($page, $total_pages);
        $offset = ($page - 1) * $this->per_page;

        $data = array(
            'active_page' => 'users',
            'users' => $this->User_model->get_all($filters, $this->per_page, $offset),
            'departments' => $this->User_model->get_departments(),
            'filters' => $filters,
            'page' => $page,
            'total_pages' => $total_pages,
            'total' => $total,
            'stat_active' => $this->User_model->count_active(),
        );

        $this->render('users/index', $data);
    }

    public function add()
    {
        $this->form_validation->set_rules('name', 'Nama Lengkap', 'required|max_length[100]');
        $this->form_validation->set_rules('department', 'Departemen', 'required|max_length[60]');
        $this->form_validation->set_rules('userId', 'User ID', 'required|is_unique[users.email]');

        if ($this->form_validation->run()) {
            $this->User_model->create(array(
                'name' => $this->input->post('name', true),
                'department' => $this->input->post('department', true),
                'email' => $this->input->post('userId', true),
                'role' => 'Staff',
                'password' => 'password123', // default password, hashed inside the model
            ));
            $this->session->set_flashdata('toast', 'User berhasil ditambahkan.');
        } else {
            $this->session->set_flashdata('toast', strip_tags(validation_errors()));
        }

        redirect('users');
    }

    public function toggle($id)
    {
        $this->User_model->toggle_status($id);
        redirect('users');
    }

    public function toggle_access($id)
    {
        // Don't allow an admin to accidentally strip their own admin access
        if ((int) $id === (int) $this->user['id']) {
            $this->session->set_flashdata('toast', 'Anda tidak bisa mengubah hak akses akun sendiri.');
            redirect('users');
            return;
        }

        $target = $this->User_model->get($id);
        if (!$target) {
            redirect('users');
            return;
        }

        $new_level = $target['access_level'] === 'admin' ? 'user' : 'admin';

        // Don't allow removing the last remaining admin
        if ($target['access_level'] === 'admin' && $new_level === 'user' && $this->User_model->count_admins() <= 1) {
            $this->session->set_flashdata('toast', 'Tidak bisa menghapus admin terakhir. Jadikan user lain admin terlebih dahulu.');
            redirect('users');
            return;
        }

        $this->User_model->set_access_level($id, $new_level);
        $this->session->set_flashdata('toast', $target['name'] . ' sekarang menjadi ' . ($new_level === 'admin' ? 'Admin' : 'User Biasa') . '.');
        redirect('users');
    }

    public function delete($id)
    {
        // Don't allow deleting your own logged-in account
        if ((int) $id === (int) $this->user['id']) {
            $this->session->set_flashdata('toast', 'Anda tidak bisa menghapus akun sendiri.');
            redirect('users');
            return;
        }
        $this->User_model->delete($id);
        $this->session->set_flashdata('toast', 'User dihapus.');
        redirect('users');
    }
}