<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function login()
    {
        // Already logged in? go straight to dashboard.
        if ($this->session->userdata('user_id')) {
            redirect('dashboard');
            return;
        }

        $error = null;

        if ($this->input->method() === 'post') {
            $this->form_validation->set_rules('alias', 'Alias', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');

            if ($this->form_validation->run()) {
                $email = $this->input->post('alias', true);
                $password = $this->input->post('password', true);

                $user = $this->User_model->get_by_email($email);

                if ($user && $user['status'] === 'Aktif' && password_verify($password, $user['password'])) {
                    $this->session->set_userdata(array(
                        'user_id' => $user['id'],
                        'user_name' => $user['name'],
                        'password' => $password,
                    ));
                    if ($password === "password123") {
                        redirect('profile');
                        return;

                    } else {
                        redirect('dashboard');
                        return;
                    }
                }

                $error = 'Email atau password salah, atau akun tidak aktif.';
            } else {
                $error = validation_errors();
            }
        }

        $this->load->view('auth/login', array('error' => $error));
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('login');
    }
}
