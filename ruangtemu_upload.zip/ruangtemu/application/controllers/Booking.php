<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Booking extends MY_Controller
{
    private $per_page = 8;

    public function index()
    {
        $filters = array(
            'q' => $this->input->get('q'),
            'room_id' => $this->input->get('room_id'),
            'status' => $this->input->get('status'),
        );

        $page = max(1, (int) $this->input->get('page'));
        $offset = ($page - 1) * $this->per_page;

        $total = $this->Booking_model->count_all($filters);
        $total_pages = max(1, (int) ceil($total / $this->per_page));
        $page = min($page, $total_pages);
        $offset = ($page - 1) * $this->per_page;

        $data = array(
            'active_page' => 'booking',
            'bookings' => $this->Booking_model->get_all($filters, $this->per_page, $offset),
            'rooms' => $this->Room_model->get_all(),
            'filters' => $filters,
            'page' => $page,
            'total_pages' => $total_pages,
            'total' => $total,
            'stat_approved' => $this->Booking_model->count_by_status('Disetujui'),
            'stat_pending' => $this->Booking_model->count_by_status('Menunggu'),
        );

        $this->render('booking/index', $data);
    }

    public function approve($id)
    {
        $this->Booking_model->set_status($id, 'Disetujui');
        $this->session->set_flashdata('toast', 'Booking disetujui.');
        redirect($this->_back_url());
    }

    public function reject($id)
    {
        $this->Booking_model->set_status($id, 'Ditolak');
        $this->session->set_flashdata('toast', 'Booking ditolak.');
        redirect($this->_back_url());
    }

    public function cancel($id)
    {
        $this->Booking_model->set_status($id, 'Ditolak');
        $this->session->set_flashdata('toast', 'Booking dibatalkan.');
        redirect($this->_back_url());
    }

    private function _back_url()
    {
        $ref = $this->input->server('HTTP_REFERER');
        return $ref ?: 'booking';
    }
}
