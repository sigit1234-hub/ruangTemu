<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model
{
    protected $table = 'users';

    public function get($id)
    {
        return $this->db->get_where($this->table, array('id' => $id))->row_array();
    }

    public function get_by_email($email)
    {
        return $this->db->get_where($this->table, array('email' => $email))->row_array();
    }

    /**
     * Returns a filtered, paginated list of users.
     * $filters: ['q' => search term, 'department' => .., 'status' => ..]
     */
    public function get_all($filters = array(), $limit = 8, $offset = 0)
    {
        $this->apply_filters($filters);
        $this->db->order_by('name', 'ASC');
        return $this->db->limit($limit, $offset)->get($this->table)->result_array();
    }

    public function count_all($filters = array())
    {
        $this->apply_filters($filters);
        return $this->db->count_all_results($this->table);
    }

    protected function apply_filters($filters)
    {
        if (!empty($filters['q'])) {
            $this->db->group_start()
                ->like('name', $filters['q'])
                ->or_like('email', $filters['q'])
                ->group_end();
        }
        if (!empty($filters['department'])) {
            $this->db->where('department', $filters['department']);
        }
        if (!empty($filters['status'])) {
            $this->db->where('status', $filters['status']);
        }
    }

    public function get_departments()
    {
        $rows = $this->db->select('department')->distinct()->order_by('department', 'ASC')->get($this->table)->result_array();
        return array_column($rows, 'department');
    }

    public function create($data)
    {
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        $data['status'] = 'Aktif';
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function update($id, $data)
    {
        // Never allow raw password overwrite through generic update()
        unset($data['password']);
        return $this->db->update($this->table, $data, array('id' => $id));
    }

    public function update_password($id, $new_plain_password)
    {
        return $this->db->update(
            $this->table,
            array('password' => password_hash($new_plain_password, PASSWORD_DEFAULT)),
            array('id' => $id)
        );
    }

    public function toggle_status($id)
    {
        $user = $this->get($id);
        if (!$user) return FALSE;
        $new_status = $user['status'] === 'Aktif' ? 'Nonaktif' : 'Aktif';
        return $this->db->update($this->table, array('status' => $new_status), array('id' => $id));
    }

    public function set_access_level($id, $access_level)
    {
        if (!in_array($access_level, array('admin', 'user'), TRUE)) return FALSE;
        return $this->db->update($this->table, array('access_level' => $access_level), array('id' => $id));
    }

    public function count_admins()
    {
        return $this->db->where('access_level', 'admin')->count_all_results($this->table);
    }

    public function delete($id)
    {
        return $this->db->delete($this->table, array('id' => $id));
    }

    public function count_active()
    {
        return $this->db->where('status', 'Aktif')->count_all_results($this->table);
    }
}
