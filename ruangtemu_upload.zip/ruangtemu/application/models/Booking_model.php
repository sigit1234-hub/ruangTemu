<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Booking_model extends CI_Model
{
    protected $table = 'bookings';

    /**
     * All bookings for a given date, keyed "roomId|slotLabel", joined with
     * the requester's name — used to render the Dashboard timeline grid.
     */
    public function get_for_date($date)
    {
        $rows = $this->db
            ->select('bookings.*, users.name AS pic_name')
            ->join('users', 'users.id = bookings.user_id')
            ->where('booking_date', $date)
            ->get($this->table)
            ->result_array();

        $keyed = array();
        foreach ($rows as $row) {
            $keyed[$row['room_id'] . '|' . $row['slot_label']] = $row;
        }
        return $keyed;
    }

    /**
     * Attempts to create a booking. Returns TRUE on success, or a string
     * error message if the slot is already taken by a non-rejected request.
     */
    public function create($user_id, $room_id, $date, $slot_label, $start_hour, $end_hour, $agenda)
    {
        $existing = $this->db->get_where($this->table, array(
            'room_id' => $room_id,
            'booking_date' => $date,
            'slot_label' => $slot_label,
        ))->row_array();

        if ($existing && $existing['status'] !== 'Ditolak') {
            return 'Slot ini sudah dipesan untuk tanggal & jam tersebut.';
        }

        $data = array(
            'user_id' => $user_id,
            'room_id' => $room_id,
            'booking_date' => $date,
            'slot_label' => $slot_label,
            'start_hour' => $start_hour,
            'end_hour' => $end_hour,
            'agenda' => $agenda,
            'status' => 'Menunggu',
        );

        if ($existing) {
            // A previously-rejected request for this exact slot: overwrite it
            // rather than violating the unique(room, date, slot) constraint.
            $this->db->update($this->table, $data, array('id' => $existing['id']));
        } else {
            $this->db->insert($this->table, $data);
        }

        return TRUE;
    }

    /**
     * Filtered + paginated list for the Data Booking page.
     * $filters: ['q' => search PIC/agenda, 'room_id' => .., 'status' => ..]
     */
    public function get_all($filters = array(), $limit = 8, $offset = 0)
    {
        $this->apply_filters($filters);
        $this->db->select('bookings.*, users.name AS pic_name, users.department AS pic_dept, rooms.name AS room_name')
            ->join('users', 'users.id = bookings.user_id')
            ->join('rooms', 'rooms.id = bookings.room_id')
            ->order_by('bookings.id', 'DESC');
            // ->order_by('bookings.start_hour', 'ASC');
        return $this->db->limit($limit, $offset)->get($this->table)->result_array();
    }

    public function count_all($filters = array())
    {
        $this->apply_filters($filters);
        $this->db->join('users', 'users.id = bookings.user_id')
            ->join('rooms', 'rooms.id = bookings.room_id');
        return $this->db->count_all_results($this->table);
    }

    protected function apply_filters($filters)
    {
        if (!empty($filters['q'])) {
            $this->db->group_start()
                ->like('users.name', $filters['q'])
                ->or_like('bookings.agenda', $filters['q'])
                ->group_end();
        }
        if (!empty($filters['room_id'])) {
            $this->db->where('bookings.room_id', $filters['room_id']);
        }
        if (!empty($filters['status'])) {
            $this->db->where('bookings.status', $filters['status']);
        }
    }

    /** All bookings ever made by one user — used on the Profile page. */
    public function get_by_user($user_id, $limit = 50)
    {
        return $this->db
            ->select('bookings.*, rooms.name AS room_name, rooms.location AS room_location')
            ->join('rooms', 'rooms.id = bookings.room_id')
            ->where('bookings.user_id', $user_id)
            ->order_by('bookings.booking_date', 'DESC')
            ->order_by('bookings.start_hour', 'ASC')
            ->limit($limit)
            ->get($this->table)
            ->result_array();
    }

    public function set_status($id, $status)
    {
        return $this->db->update($this->table, array('status' => $status), array('id' => $id));
    }

    public function count_by_status($status, $date = NULL)
    {
        if ($date) $this->db->where('booking_date', $date);
        return $this->db->where('status', $status)->count_all_results($this->table);
    }

    /**
     * New pending ("Menunggu") requests created after $since — used to
     * notify admins of incoming booking requests without opening the page.
     */
    public function get_new_pending_since($since)
    {
        return $this->db
            ->select('bookings.*, users.name AS pic_name, rooms.name AS room_name')
            ->join('users', 'users.id = bookings.user_id')
            ->join('rooms', 'rooms.id = bookings.room_id')
            ->where('bookings.status', 'Menunggu')
            ->where('bookings.created_at >', $since)
            ->order_by('bookings.created_at', 'ASC')
            ->get($this->table)
            ->result_array();
    }

    /**
     * A single user's bookings whose status changed to Disetujui/Ditolak
     * after $since — used to notify that user of a decision on their request.
     */
    public function get_status_changes_since($user_id, $since)
    {
        return $this->db
            ->select('bookings.*, rooms.name AS room_name')
            ->join('rooms', 'rooms.id = bookings.room_id')
            ->where('bookings.user_id', $user_id)
            ->where_in('bookings.status', array('Disetujui', 'Ditolak'))
            ->where('bookings.updated_at >', $since)
            ->order_by('bookings.updated_at', 'ASC')
            ->get($this->table)
            ->result_array();
    }
}
