<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Slot_model extends CI_Model
{
    protected $table = 'time_slots';

    public function get_all()
    {
        return $this->db->order_by('sort_order', 'ASC')->order_by('start_hour', 'ASC')->get($this->table)->result_array();
    }

    public function get($id)
    {
        return $this->db->get_where($this->table, array('id' => $id))->row_array();
    }

    public function create($start_hour, $end_hour)
    {
        $label = $this->make_label($start_hour, $end_hour);
        $max = $this->db->select_max('sort_order')->get($this->table)->row_array();
        $next_order = isset($max['sort_order']) ? ((int) $max['sort_order'] + 1) : 1;

        $this->db->insert($this->table, array(
            'label' => $label,
            'start_hour' => $start_hour,
            'end_hour' => $end_hour,
            'sort_order' => $next_order,
        ));
        return $this->db->insert_id();
    }

    public function update($id, $start_hour, $end_hour)
    {
        return $this->db->update($this->table, array(
            'label' => $this->make_label($start_hour, $end_hour),
            'start_hour' => $start_hour,
            'end_hour' => $end_hour,
        ), array('id' => $id));
    }

    public function delete($id)
    {
        return $this->db->delete($this->table, array('id' => $id));
    }

    public function make_label($start_hour, $end_hour)
    {
        return sprintf('%02d.00-%02d.00', $start_hour, $end_hour);
    }
}
