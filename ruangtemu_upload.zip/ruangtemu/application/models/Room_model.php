<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Room_model extends CI_Model
{
    protected $table = 'rooms';

    public function get_all()
    {
        return $this->db->order_by('id', 'ASC')->get($this->table)->result_array();
    }

    public function get($id)
    {
        return $this->db->get_where($this->table, array('id' => $id))->row_array();
    }

    public function count_all()
    {
        return $this->db->count_all($this->table);
    }

    public function create($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function update($id, $data)
    {
        return $this->db->update($this->table, $data, array('id' => $id));
    }

    public function delete($id)
    {
        return $this->db->delete($this->table, array('id' => $id));
    }

    /** How many bookings (of any status) reference this room. Used to block deletion. */
    public function count_bookings($room_id)
    {
        return $this->db->where('room_id', $room_id)->count_all_results('bookings');
    }
}
