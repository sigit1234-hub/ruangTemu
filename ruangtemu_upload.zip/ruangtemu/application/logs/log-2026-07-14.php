<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-07-14 04:27:19 --> 404 Page Not Found: Auth/index
ERROR - 2026-07-14 04:39:46 --> Severity: error --> Exception: password_verify() expects exactly 2 arguments, 1 given C:\laragon\www\ruangtemu\application\controllers\Auth.php 31
ERROR - 2026-07-14 04:45:11 --> Query error: Incorrect DATE value: 'NaN-NaN-NaN' - Invalid query: SELECT `bookings`.*, `users`.`name` AS `pic_name`
FROM `bookings`
JOIN `users` ON `users`.`id` = `bookings`.`user_id`
WHERE `booking_date` = 'NaN-NaN-NaN'
ERROR - 2026-07-14 04:46:17 --> Severity: error --> Exception: syntax error, unexpected token "::", expecting "(" C:\laragon\www\ruangtemu\application\controllers\Dashboard.php 7
