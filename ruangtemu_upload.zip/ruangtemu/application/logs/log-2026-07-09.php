<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-07-09 09:34:25 --> Severity: Warning --> Undefined array key "email" C:\laragon\www\ruangtemu\application\views\users\index.php 75
ERROR - 2026-07-09 09:34:25 --> Severity: Warning --> Undefined array key "email" C:\laragon\www\ruangtemu\application\views\users\index.php 75
ERROR - 2026-07-09 09:34:25 --> Severity: Warning --> Undefined array key "email" C:\laragon\www\ruangtemu\application\views\users\index.php 75
ERROR - 2026-07-09 09:34:25 --> Severity: Warning --> Undefined array key "email" C:\laragon\www\ruangtemu\application\views\users\index.php 75
ERROR - 2026-07-09 09:34:25 --> Severity: Warning --> Undefined array key "email" C:\laragon\www\ruangtemu\application\views\users\index.php 75
ERROR - 2026-07-09 09:34:25 --> Severity: Warning --> Undefined array key "email" C:\laragon\www\ruangtemu\application\views\profile\index.php 31
ERROR - 2026-07-09 09:34:25 --> Severity: Warning --> Undefined array key "email" C:\laragon\www\ruangtemu\application\views\profile\index.php 66
ERROR - 2026-07-09 09:40:00 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `email` IS NULL
