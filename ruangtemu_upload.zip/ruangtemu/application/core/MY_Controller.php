<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * MY_Controller
 *
 * Base controller: every page controller (Dashboard, Booking, Users, Profile)
 * extends this so login is enforced and the current user is always available.
 */
class MY_Controller extends CI_Controller
{
    protected $user; // logged-in user's row (array) from `users` table

    /** Controllers only an 'admin' access_level user may open. */
    protected $admin_only_classes = array('booking', 'users', 'rooms');

    public function __construct()
    {
        parent::__construct();

        $user_id = $this->session->userdata('user_id');

        if (!$user_id && $this->router->fetch_class() !== 'auth') {
            redirect('login');
            return;
        }

        if ($user_id) {
            $this->user = $this->User_model->get($user_id);

            // Session references a user that no longer exists / was deactivated
            if (!$this->user || $this->user['status'] !== 'Aktif') {
                $this->session->sess_destroy();
                redirect('login');
                return;
            }

            $current_class = strtolower($this->router->fetch_class());
            if (in_array($current_class, $this->admin_only_classes, TRUE) && $this->user['access_level'] !== 'admin') {
                $this->session->set_flashdata('toast', 'Anda tidak memiliki akses ke halaman tersebut.');
                redirect('dashboard');
                return;
            }
        }
    }

    /**
     * Renders a full page: templates/header + templates/sidebar + $view + templates/footer
     */
    protected function render($view, $data = array())
    {
        $data['current_user'] = $this->user;
        $data['active_page'] = isset($data['active_page']) ? $data['active_page'] : '';

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view($view, $data);
        $this->load->view('templates/footer', $data);
    }

    /** Convenience: send a JSON response and stop */
    protected function json($data)
    {
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($data));
    }
}
