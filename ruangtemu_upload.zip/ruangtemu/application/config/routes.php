<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'dashboard';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// Auth
$route['login'] = 'auth/login';
$route['logout'] = 'auth/logout';

// Dashboard (timeline booking)
$route['dashboard'] = 'dashboard/index';
$route['dashboard/get_timeline'] = 'dashboard/get_timeline';
$route['dashboard/book'] = 'dashboard/book';

// Data Booking
$route['booking'] = 'booking/index';
$route['booking/approve/(:num)'] = 'booking/approve/$1';
$route['booking/reject/(:num)'] = 'booking/reject/$1';
$route['booking/cancel/(:num)'] = 'booking/cancel/$1';

// Data Users
$route['users'] = 'users/index';
$route['users/add'] = 'users/add';
$route['users/toggle/(:num)'] = 'users/toggle/$1';
$route['users/toggle_access/(:num)'] = 'users/toggle_access/$1';
$route['users/delete/(:num)'] = 'users/delete/$1';

// Kelola Ruang & Jam (admin only)
$route['rooms'] = 'rooms/index';
$route['rooms/add_room'] = 'rooms/add_room';
$route['rooms/update_room/(:num)'] = 'rooms/update_room/$1';
$route['rooms/delete_room/(:num)'] = 'rooms/delete_room/$1';
$route['rooms/add_slot'] = 'rooms/add_slot';
$route['rooms/update_slot/(:num)'] = 'rooms/update_slot/$1';
$route['rooms/delete_slot/(:num)'] = 'rooms/delete_slot/$1';

// Profile
$route['profile'] = 'profile/index';
$route['profile/update'] = 'profile/update';
