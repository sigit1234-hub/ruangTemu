<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();
$autoload['libraries'] = array('database', 'session', 'form_validation');
$autoload['drivers'] = array();
$autoload['helper'] = array('url', 'form', 'date', 'html', 'asset');
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array('User_model', 'Room_model', 'Booking_model', 'Slot_model');
