<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * asset_url()
 *
 * Same as base_url(), but appends "?v=<file modification time>" to the
 * URL for local files. This busts the browser cache automatically the
 * moment a CSS/JS file is updated on the server — no more "I fixed the
 * bug but the site still shows the old behaviour until I hard-refresh"
 * confusion after a deploy.
 *
 * Falls back to a plain base_url() if the file can't be found on disk
 * (e.g. an external URL was passed in).
 */
if (!function_exists('asset_url')) {
    function asset_url($relative_path)
    {
        $CI =& get_instance();
        $full_path = FCPATH . ltrim($relative_path, '/');

        if (is_file($full_path)) {
            return base_url($relative_path) . '?v=' . filemtime($full_path);
        }

        return base_url($relative_path);
    }
}
