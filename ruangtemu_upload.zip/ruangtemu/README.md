# RuangTemu — CodeIgniter 3 + Backend (MySQL)

Ini adalah versi **backend** dari aplikasi booking ruang meeting RuangTemu,
dibangun di atas **CodeIgniter 3**. Paket ini berisi folder `application/`,
`assets/`, file SQL, dan `.htaccess` — bukan seluruh source framework CI3
(folder `system/` bawaan CodeIgniter tidak disertakan karena itu adalah kode
resmi framework, bukan bagian yang perlu disesuaikan untuk proyek ini).

## 1. Download CodeIgniter 3

Unduh CodeIgniter 3 resmi dari:
https://github.com/bcit-ci/CodeIgniter/releases (pilih versi 3.1.x terbaru)

Extract, lalu Anda akan mendapati struktur:
```
CodeIgniter-3.x.x/
├── application/
├── system/
├── index.php
└── ...
```

## 2. Gabungkan dengan paket ini

1. **Hapus** folder `application/` bawaan CodeIgniter, lalu **ganti** dengan
   folder `application/` dari paket ini.
2. Salin folder `assets/` dan file `.htaccess` dari paket ini ke root project
   (sejajar dengan `index.php` dan `system/`).
3. Struktur akhir harus terlihat seperti:
```
project/
├── application/      <-- dari paket ini
├── assets/           <-- dari paket ini
├── system/           <-- bawaan CodeIgniter, jangan diubah
├── database/         <-- dari paket ini (file .sql & script hash password)
├── .htaccess         <-- dari paket ini
└── index.php         <-- bawaan CodeIgniter, jangan diubah
```

## 3. Buat database

1. Buat database MySQL/MariaDB, lalu import `database/ruangtemu.sql`
   (file ini sudah membuat database `ruangtemu`, tabel, dan data contoh).
2. **Set password login yang benar-benar valid** — password di file SQL
   hanya placeholder karena hash bcrypt harus dibuat oleh PHP itu sendiri.
   Edit koneksi database di `database/hash_passwords.php`, lalu jalankan:
   ```
   php database/hash_passwords.php
   ```
   Ini akan mengeset password **password123** untuk semua user contoh.

## 4. Konfigurasi

Edit `application/config/database.php` sesuai kredensial MySQL Anda
(`hostname`, `username`, `password`, `database`).

Edit `application/config/config.php` → `$config['base_url']` sesuai lokasi
project Anda, misalnya `http://localhost/ruangtemu/`.

Jika ingin URL tanpa `index.php` (mis. `http://localhost/ruangtemu/dashboard`),
pastikan module `mod_rewrite` Apache aktif — `.htaccess` yang disertakan sudah
menghapus `index.php` dari URL secara otomatis.

## 5. Login default

| Email                          | Password    |
|---------------------------------|-------------|
| sigit.prasetyo@perusahaan.com  | password123 |
| barokah@perusahaan.com         | password123 |
| dewi.anjani@perusahaan.com     | password123 |

(Setelah menjalankan `hash_passwords.php` sesuai langkah 3.)

## Struktur fitur

- **Dashboard** (`/dashboard`) — tabel timeline ketersediaan ruangan per
  tanggal, klik slot kosong untuk mengajukan booking (AJAX ke
  `dashboard/book`), navigasi tanggal, dan mode layar penuh untuk
  ditampilkan di TV/kiosk. **Bisa diakses oleh admin maupun user biasa.**
- **Data Booking** (`/booking`) — daftar semua pengajuan booking dengan
  pencarian, filter ruangan/status, dan aksi setujui/tolak/batalkan.
  **Khusus admin.**
- **Data Users** (`/users`) — daftar pengguna dengan pencarian, filter
  departemen/status, tambah user baru, aktif/nonaktifkan, hapus user, dan
  **mengubah hak akses (Admin / User Biasa)** lewat tombol bintang di
  setiap baris. **Khusus admin.**
- **Kelola Ruang & Jam** (`/rooms`) — **baru**: halaman untuk menambah,
  mengedit, dan menghapus daftar ruangan (nama, lokasi, kapasitas) serta
  pilihan jam booking (jam mulai/selesai, label dibuat otomatis).
  Menghapus ruangan yang masih punya data booking akan ditolak sistem.
  **Khusus admin.**
- **Profile** (`/profile`) — menampilkan detail data pegawai yang sedang
  login (nama, email, no. telp, departemen, status, tanggal bergabung),
  form untuk memperbarui data tersebut (termasuk ganti password opsional),
  dan riwayat semua peminjaman ruang yang pernah diajukan pegawai tersebut.
  **Bisa diakses oleh admin maupun user biasa.**

## Hak akses (role)

Setiap user punya kolom `access_level`: `admin` atau `user`.

- **Admin** — akses ke semua halaman: Dashboard, Data Booking, Data Users,
  Kelola Ruang & Jam, dan Profile.
- **User Biasa** — hanya bisa mengakses **Dashboard**, **Profile**, dan
  **Logout**. Jika mencoba membuka URL Data Booking/Data Users/Kelola Ruang
  secara langsung, sistem akan menolak dan mengarahkan kembali ke Dashboard
  dengan pesan peringatan.

User pertama (Sigit Prasetyo) sudah di-set sebagai **admin** di data contoh.
Admin bisa mempromosikan/menurunkan user lain lewat tombol hak akses di
halaman Data Users (tidak bisa mengubah hak akses akun sendiri, dan sistem
akan menolak jika itu akan menghilangkan admin terakhir).

## Jika Anda sudah pernah meng-import versi sebelumnya

Jalankan `database/upgrade_v2.sql` (bukan `ruangtemu.sql` lagi) untuk
menambahkan kolom `access_level` dan tabel `time_slots` tanpa mengulang
import dari awal.

## Troubleshooting: "ERR_TOO_MANY_REDIRECTS" / redirect loop ke `/login`

Ini selalu berarti **session tidak tersimpan** antar request (jadi
`MY_Controller` mengira Anda belum login terus-menerus, walaupun sudah
login berkali-kali). Urutan pengecekan:

1. **Buka di mode Incognito, atau hapus cookies untuk `localhost`.**
   Kalau langsung normal → ada cookie session lama dari percobaan
   sebelumnya (mis. base_url berbeda) yang bikin bentrok. Hapus saja.

2. **Pastikan folder `application/sessions/` bisa ditulis oleh web
   server** (chmod 755/777 di Linux, atau pastikan user IIS/Apache di
   Windows punya izin tulis). Folder ini sudah disiapkan di
   `application/config/config.php` sebagai `sess_save_path`, menggantikan
   `sys_get_temp_dir()` yang di beberapa setup XAMPP/Windows tidak bisa
   ditulis oleh Apache — akibatnya session gagal tersimpan **tanpa error
   yang terlihat**, dan Anda selalu dianggap belum login.

3. **`base_url` harus sama persis** dengan alamat di address bar,
   termasuk subfolder dan garis miring di akhir. Contoh kalau project ada
   di `http://localhost/ruangMeeting2/`, maka:
   ```php
   $config['base_url'] = 'http://localhost/ruangMeeting2/';
   ```

4. **Kalau project ada di subfolder** (bukan di root `htdocs`), buka
   `.htaccess` dan aktifkan baris `RewriteBase`, sesuaikan dengan nama
   folder Anda:
   ```
   RewriteBase /ruangMeeting2/
   ```

5. Cek `application/logs/` (aktifkan dengan `$config['log_threshold'] = 2;`
   sementara) — kalau ada baris seperti `Session: Unable to write...`,
   itu konfirmasi masalahnya memang di sesi, bukan di base_url.

## Catatan keamanan untuk produksi

- `csrf_protection` dimatikan (`FALSE`) di `config.php` agar AJAX booking
  di Dashboard tidak perlu mengirim token — aktifkan kembali (`TRUE`) untuk
  produksi dan sesuaikan `assets/js/dashboard.js` agar menyertakan CSRF
  token pada request POST-nya.
- Ganti `encryption_key` di `config.php` dengan string acak yang unik.
- Set `db_debug` ke `FALSE` di lingkungan produksi (`ENVIRONMENT` = `production`).
