-- ============================================================
-- Upgrade script — run this ONLY if you already imported the
-- earlier version of ruangtemu.sql (without access_level / time_slots).
-- If you're importing fresh, just use ruangtemu.sql — you don't need this.
-- ============================================================
USE `ruangtemu`;

ALTER TABLE `users`
  ADD COLUMN `access_level` ENUM('admin','user') NOT NULL DEFAULT 'user' AFTER `role`;

-- Make the first user an admin so someone can access Data Booking / Data Users / Kelola Ruang
UPDATE `users` SET `access_level` = 'admin' WHERE `id` = 1;

CREATE TABLE IF NOT EXISTS `time_slots` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `label` VARCHAR(30) NOT NULL,
  `start_hour` TINYINT UNSIGNED NOT NULL,
  `end_hour` TINYINT UNSIGNED NOT NULL,
  `sort_order` INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB;

INSERT INTO `time_slots` (`label`, `start_hour`, `end_hour`, `sort_order`) VALUES
('08.00-10.00', 8, 10, 1),
('10.00-12.00', 10, 12, 2),
('13.00-15.00', 13, 15, 3),
('15.00-17.00', 15, 17, 4);
