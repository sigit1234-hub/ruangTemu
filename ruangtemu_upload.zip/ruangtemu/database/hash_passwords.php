<?php
/**
 * Run this ONCE after importing database/ruangtemu.sql:
 *
 *   php database/hash_passwords.php
 *
 * It sets every seeded user's password to: password123
 * using PHP's own password_hash(), so the hash is guaranteed to be
 * valid on whatever PHP version/server you're running (unlike a
 * hash pasted in from elsewhere).
 *
 * Edit the $host/$db/$user/$pass constants below to match your
 * application/config/database.php before running.
 */

$host = "localhost";
$db   = "ruangtemu";
$user = "root";
$pass = "";

$plainPassword = "password123";

$mysqli = new mysqli($host, $user, $pass, $db);
if ($mysqli->connect_error) {
    die("Koneksi database gagal: " . $mysqli->connect_error . "\n");
}

$hash = password_hash($plainPassword, PASSWORD_DEFAULT);

$stmt = $mysqli->prepare("UPDATE users SET password = ? WHERE password = 'CHANGE_ME_RUN_hash_passwords.php'");
$stmt->bind_param("s", $hash);
$stmt->execute();

echo "Selesai. {$stmt->affected_rows} user password di-set ke: {$plainPassword}\n";

$stmt->close();
$mysqli->close();
