-- ============================================================
-- RuangTemu — Database schema & seed data
-- Import this file into MySQL/MariaDB before running the app.
-- ============================================================

CREATE DATABASE IF NOT EXISTS `ruangtemu` DEFAULT CHARACTER SET utf8mb4;
USE `ruangtemu`;

-- ------------------------------------------------------------
-- Table: users  (pegawai / karyawan)
-- ------------------------------------------------------------
CREATE TABLE `users` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `phone` VARCHAR(25) DEFAULT NULL,
  `department` VARCHAR(60) DEFAULT NULL,
  `role` VARCHAR(60) DEFAULT 'Staff',
  `access_level` ENUM('admin','user') NOT NULL DEFAULT 'user',
  `password` VARCHAR(255) NOT NULL,
  `status` ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: rooms
-- ------------------------------------------------------------
CREATE TABLE `rooms` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `location` VARCHAR(100) DEFAULT NULL,
  `capacity` INT DEFAULT 10
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: time_slots  (jam yang bisa dipilih saat booking)
-- ------------------------------------------------------------
CREATE TABLE `time_slots` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `label` VARCHAR(30) NOT NULL,
  `start_hour` TINYINT UNSIGNED NOT NULL,
  `end_hour` TINYINT UNSIGNED NOT NULL,
  `sort_order` INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: bookings  (peminjaman ruang meeting)
-- ------------------------------------------------------------
CREATE TABLE `bookings` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `room_id` INT UNSIGNED NOT NULL,
  `booking_date` DATE NOT NULL,
  `slot_label` VARCHAR(30) NOT NULL,
  `start_hour` TINYINT UNSIGNED NOT NULL,
  `end_hour` TINYINT UNSIGNED NOT NULL,
  `agenda` VARCHAR(255) NOT NULL,
  `status` ENUM('Menunggu','Disetujui','Ditolak') NOT NULL DEFAULT 'Menunggu',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_booking_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_booking_room` FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `uniq_slot` (`room_id`, `booking_date`, `slot_label`)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Seed: rooms
-- ------------------------------------------------------------
INSERT INTO `rooms` (`id`, `name`, `location`, `capacity`) VALUES
(1, 'Ruang Besar', 'Kantor A Lt.9', 12),
(2, 'Ruang Kecil',  'Kantor A Lt.9', 6),
(3, 'Ruang MB',     'MB Lt.40', 20);

-- ------------------------------------------------------------
-- Seed: time_slots
-- ------------------------------------------------------------
INSERT INTO `time_slots` (`id`, `label`, `start_hour`, `end_hour`, `sort_order`) VALUES
(1, '08.00-10.00', 8, 10, 1),
(2, '10.00-12.00', 10, 12, 2),
(3, '13.00-15.00', 13, 15, 3),
(4, '15.00-17.00', 15, 17, 4);

-- ------------------------------------------------------------
-- Seed: users
-- The `password` column below is a placeholder — it is NOT a valid
-- bcrypt hash. After importing this file, run the included PHP
-- script to set a real, working password hash for every seeded user:
--
--   php database/hash_passwords.php
--
-- That script sets every seeded user's password to: password123
-- (see README.md → "Login default" for details)
-- ------------------------------------------------------------
INSERT INTO `users` (`id`, `name`, `email`, `phone`, `department`, `role`, `access_level`, `password`, `status`) VALUES
(1, 'Sigit Prasetyo', 'sigit.prasetyo@perusahaan.com', '0812-3456-7801', 'SGA',         'Staff', 'admin', 'CHANGE_ME_RUN_hash_passwords.php', 'Aktif'),
(2, 'Barokah',        'barokah@perusahaan.com',        '0813-2233-4455', 'PVA',         'Staff', 'user',  'CHANGE_ME_RUN_hash_passwords.php', 'Aktif'),
(3, 'Dewi Anjani',    'dewi.anjani@perusahaan.com',    '0821-5566-7788', 'Marketing',   'Staff', 'user',  'CHANGE_ME_RUN_hash_passwords.php', 'Aktif'),
(4, 'Rizky Ramadhan', 'rizky.ramadhan@perusahaan.com', '0857-1122-3344', 'Finance',     'Staff', 'user',  'CHANGE_ME_RUN_hash_passwords.php', 'Aktif'),
(5, 'Novi Kartika',   'novi.kartika@perusahaan.com',   '0878-4455-6677', 'HR',          'Staff', 'user',  'CHANGE_ME_RUN_hash_passwords.php', 'Aktif');

-- ------------------------------------------------------------
-- Seed: bookings
-- ------------------------------------------------------------
INSERT INTO `bookings` (`user_id`, `room_id`, `booking_date`, `slot_label`, `start_hour`, `end_hour`, `agenda`, `status`) VALUES
(2, 3, CURDATE(), '13.00-15.00', 13, 15, 'Meeting tim PVA', 'Disetujui'),
(2, 3, CURDATE(), '15.00-17.00', 15, 17, 'Meeting tim PVA', 'Disetujui'),
(3, 2, CURDATE(), '10.00-12.00', 10, 12, 'Review materi campaign Q3', 'Menunggu'),
(1, 1, CURDATE(), '08.00-10.00', 8, 10, 'Sinkronisasi mingguan tim SGA', 'Disetujui'),
(4, 2, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '08.00-10.00', 8, 10, 'Rekonsiliasi anggaran bulanan', 'Disetujui'),
(5, 1, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '13.00-15.00', 13, 15, 'Wawancara kandidat staff baru', 'Disetujui');
